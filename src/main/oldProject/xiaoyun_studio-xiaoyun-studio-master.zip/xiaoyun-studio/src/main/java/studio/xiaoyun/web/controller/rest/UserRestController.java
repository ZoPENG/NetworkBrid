package studio.xiaoyun.web.controller.rest;

import org.apache.shiro.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import studio.xiaoyun.common.exception.ErrorCode;
import studio.xiaoyun.common.exception.XysException;
import studio.xiaoyun.core.constant.Permission;
import studio.xiaoyun.core.dao.IUserDao;
import studio.xiaoyun.core.entity.UserEntity;
import studio.xiaoyun.core.service.IUserService;
import studio.xiaoyun.security.annotation.RequirePermission;
import studio.xiaoyun.web.RestResult;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

/**
 * 用户相关
 */
@RestController
@RequestMapping("/v1/user")
public class UserRestController {
    @Resource
    private IUserDao userDao;
    @Resource
    private IUserService userService;

    @RequirePermission(Permission.USER_CREATE)
    @RequestMapping(value = "",method = RequestMethod.PUT)
    public RestResult createUser(String email, String password) {
        if(!StringUtils.hasText(email) || !StringUtils.hasText(password)){
            throw new XysException(ErrorCode.PARAMETER_ERROR,"邮箱和密码不能为空!");
        }
        String userID = userService.createUser(email,password);
        UserEntity user = userDao.getById(userID);
        Map<String,String> map = new HashMap<>();
        map.put("name",user.getName()+" ");
        return new RestResult(1,map);
    }
}
