package studio.xiaoyun.web.resource;

import java.util.Date;

/**
 * 意见反馈
 * @author 岳正灵
 */
public class FeedbackResource implements Resource {
	private String feedbackId;
	private String title;
	private String text;
	private Date createDate;
	
	public Date getCreateDate() {
		return createDate;
	}
	public String getFeedbackId() {
		return feedbackId;
	}
	public String getText() {
		return text;
	}
	public String getTitle() {
		return title;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public void setFeedbackId(String feedbackId) {
		this.feedbackId = feedbackId;
	}
	public void setText(String text) {
		this.text = text;
	}
	public void setTitle(String title) {
		this.title = title;
	}

}
