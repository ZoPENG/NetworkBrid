package studio.xiaoyun.common.exception;

/**
 * 所有自定义异常的超类,xys是xiao yun studio的缩写
 */
public class XysException extends RuntimeException {

	private static final long serialVersionUID = -2097465532154739597L;
	private ErrorCode errorCode;

	/**
	 *
	 * @param message 错误信息
     */
	public XysException(String message){
		super(message);
	}

	/**
	 *
	 * @param message 错误信息
	 * @param e 原始异常
     */
	public XysException(String message,Exception e){
		super(message,e);
	}

	/**
	 *
	 * @param errorCode 错误码
	 * @param message 错误信息
     */
	public XysException(ErrorCode errorCode, String message){
		super(message);
		this.errorCode = errorCode;
	}

	/**
	 *
	 * @param errorCode 错误码
	 * @param message 错误信息
     * @param e 原始异常
     */
	public XysException(ErrorCode errorCode, String message,Exception e){
		super(message,e);
		this.errorCode = errorCode;
	}

	/**
	 * 取得错误码
	 * @return 错误码 , 如果没有设置错误码，则返回
	 * {@link ErrorCode#INTERNAL_SERVER_ERROR INTERNAL_SERVER_ERROR}
	 */
	public ErrorCode getErrorCode(){
		return errorCode==null?ErrorCode.INTERNAL_SERVER_ERROR:errorCode;
	}
}
