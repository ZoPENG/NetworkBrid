package studio.xiaoyun.core.parameter;

import studio.xiaoyun.core.constant.UserStatus;
import studio.xiaoyun.core.constant.UserType;
import studio.xiaoyun.core.parameter.criterion.Criterion;
import studio.xiaoyun.core.parameter.criterion.Query;

import java.util.Date;
import java.util.List;

/**
 * 用户搜索类
 */
public class UserParameter extends Parameter{
    /**
     * 用户id
     */
    private String userId;
    /**
     * 用户的名称
     */
    private String name;
    /**
     * 注册时间
     */
    private Date createDate;
    /**
     * 邮箱
     */
    private String email;
    /**
     * 状态
     */
    private UserStatus status;
    /**
     * 类型
     */
    private UserType type;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public UserStatus getStatus() {
        return status;
    }

    public void setStatus(UserStatus status) {
        this.status = status;
    }

    public UserType getType() {
        return type;
    }

    public void setType(UserType type) {
        this.type = type;
    }

    @Override
    protected List<Criterion> getDefaultValue() {
        List<Criterion> defaultValue = super.getDefaultValue();
        defaultValue.add(Query.equals("status",UserStatus.NORMAL));
        defaultValue.add(Query.equals("type",UserType.USER));
        return defaultValue;
    }
}
