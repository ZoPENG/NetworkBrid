package studio.xiaoyun.web;

import com.fasterxml.jackson.databind.ObjectMapper;
import studio.xiaoyun.common.exception.InvalidParameterException;
import studio.xiaoyun.common.exception.XysException;
import studio.xiaoyun.core.parameter.Parameter;
import studio.xiaoyun.core.parameter.criterion.Criterion;
import studio.xiaoyun.core.parameter.criterion.Query;

import javax.servlet.http.HttpServletRequest;
import java.net.URLDecoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 辅助类，方便从HTTP请求中获得参数
 * @author 岳正灵
 * @since 1.0.0
 */
public class ParameterUtil {
	private ParameterUtil(){}

	/**
	 * 从请求中获得Boolean类型的参数
	 * @param request HTTP请求
	 * @param parameterName 参数名
	 * @param defaultValue 默认值
	 * @return 参数的值,如果指定的参数不存在，则返回默认值，如果参数不是一个Boolean类型的值，则返回false
     */
	public static Boolean getBoolean(HttpServletRequest request,String parameterName,Boolean defaultValue){
		String value = request.getParameter(parameterName);
		if(value!=null){
			return Boolean.valueOf(value);
		}else{
			return defaultValue;
		}
	}

	/**
	 * 从请求中获得Date类型的参数。
	 * <p>参数的格式应该是yyyy-MM-dd
	 * @param request HTTP请求
	 * @param parameterName 参数名
	 * @return 参数的值，如果参数不存在，则返回null
	 * @throws InvalidParameterException 如果参数的值不是Date类型，则抛出异常
	 */
	public static Date getDate(HttpServletRequest request,String parameterName)throws InvalidParameterException {
		return getDate(request,parameterName,"yyyy-MM-dd");
	}
	
	/**
	 * 从请求中获得Date类型的参数
	 * @param request HTTP请求
	 * @param parameterName 参数名
	 * @param pattern 日期格式, 例如:yyyy-MM-dd
	 * @return 参数的值，如果参数不存在，则返回null
	 * @throws InvalidParameterException 如果参数的值不是Date类型，则抛出异常
	 */
	public static Date getDate(HttpServletRequest request,String parameterName,String pattern)throws InvalidParameterException {
		Date date = null;
		String value = request.getParameter(parameterName);
		if(value!=null){
			try{
				date = new SimpleDateFormat(pattern).parse(value);
			}catch(ParseException e){
				throw new InvalidParameterException("参数"+parameterName+"的格式错误:"+value);
			}
		}
		return date;
	}
	
	/**
	 * 从请求中获得Double类型的参数
	 * @param request HTTP请求
	 * @param parameterName 参数名
	 * @param defaultValue 默认值
	 * @return 参数的值，如果参数不存在，则返回默认值
	 * @throws InvalidParameterException 如果参数的值不是Double类型，则抛出异常
	 */
	public static Double getDouble(HttpServletRequest request,String parameterName,Double defaultValue)throws InvalidParameterException {
		Double result = defaultValue;
		String value = request.getParameter(parameterName);
		if(value!=null){
			try{
				result = Double.valueOf(value.trim());
			}catch(NumberFormatException e){
				throw new InvalidParameterException(parameterName+"参数应该是数字:"+value);
			}
		}
		return result;
	}
	
	/**
	 * 从HTTP请求中取得{@linkplain studio.xiaoyun.web.PublicParameter#FIELD field}的值。
	 * <p>多个值之间以逗号分隔
	 * @param request HTTP请求
	 * @return 返回结果中应该包括的字段。如果没有数据，则返回空列表
	 */
	public static List<String> getIncludeFields(HttpServletRequest request){
		List<String> result;
		String value = request.getParameter(PublicParameter.FIELD.value());
		if(value!=null){
			if(value.matches("[0-9a-zA-Z_]+(,[0-9a-zA-Z_]+)*")){
				result = Arrays.asList(value.split(","));
			}else{
				throw new InvalidParameterException("参数"+PublicParameter.FIELD.value()+"的格式错误:"+value);
			}
		}else{
			result = new LinkedList<>();
		}
		return result;
	}
	
	/**
	 * 从请求中获得整数类型的参数
	 * @param request HTTP请求
	 * @param parameterName 参数名
	 * @param defaultValue 默认值
	 * @return 参数的值，如果参数不存在，则返回默认值
	 * @throws InvalidParameterException 如果参数的值不是整数类型，则抛出异常
	 */
	public static Integer getInt(HttpServletRequest request,String parameterName,Integer defaultValue)throws InvalidParameterException {
		Integer result = defaultValue;
		String value = request.getParameter(parameterName);
		if(value!=null){
			try{
				result = Integer.valueOf(value.trim());
			}catch(NumberFormatException e){
				throw new InvalidParameterException(parameterName+"参数应该是整数:"+value);
			}
		}
		return result;
	}
	
	/**
	 * 从请求中获得整数类型的参数
	 * @param request HTTP请求
	 * @param parameterName 参数名
	 * @param defaultValue 默认值
	 * @return 参数的值，如果参数不存在，则返回默认值
	 * @throws InvalidParameterException 如果参数的值不是整数类型，则抛出异常
	 */
	public static Long getLong(HttpServletRequest request,String parameterName,Long defaultValue)throws InvalidParameterException {
		Long result = defaultValue;
		String value = request.getParameter(parameterName);
		if(value!=null){
			try{
				result = Long.valueOf(value.trim());
			}catch(NumberFormatException e){
				throw new InvalidParameterException(parameterName+"参数应该是整数:"+value);
			}
		}
		return result;
	}
	
	/**
	 * 将HTTP请求中的通用查询参数封装为参数类
	 * @param request HTTP请求
	 * @param parameter 参数类
	 * @return 参数类的实例
	 * @see studio.xiaoyun.web.PublicParameter PublicParameter
	 */
	public static <T extends Parameter> T getParameter(HttpServletRequest request,Class<T> parameter){
		Parameter result;
		try{
			result = parameter.newInstance();
		}catch(Exception e){
			throw new InvalidParameterException(parameter.getName()+"实例化失败,"+e.getMessage());
		}
		int start = getStart(request);
		int rows = getRows(request);
        List<String> includeFields = getIncludeFields(request);
        List<Object[]> sortFields = getSortFields(request);
        List<Criterion> criterions = getCriterions(request);
        for(Object[] objs:sortFields){
        	result.addSort((String)objs[0], (Boolean)objs[1]);
        }
        for(Criterion c:criterions){
        	result.addQuery(c);
        }
        result.addIncludeField(includeFields.toArray(new String[0]));
		result.setFirstResult(start);
		result.setMaxResults(rows);
		if(!result.validate()){
			throw new InvalidParameterException("查询条件无法解析!");
		}
		return (T)result;
	}
	
	@SuppressWarnings("rawtypes")
	private static List<Criterion> getCriterions(HttpServletRequest request){
		List<Criterion> result = new LinkedList<>();
		String value = request.getParameter(PublicParameter.QUERY.value());
		if(value!=null){
			try{
				ObjectMapper mapper = new ObjectMapper();
				boolean isEncode = getBoolean(request,PublicParameter.QUERY_ENCODE.value(),false);
				if(isEncode){  //如果为true，说明使用了urlencode
					value = URLDecoder.decode(value, "utf-8");
				}
				Map map = mapper.readValue(value, Map.class);
				result.addAll(getCriterions(map));
			}catch(XysException e){
				throw e;
			}catch(Exception e){
				throw new InvalidParameterException("参数"+PublicParameter.QUERY.value()+"的值无法解析:"+value);
			}
		}
		return result;
	}
	
	@SuppressWarnings("rawtypes")
	private static List<Criterion> getCriterions(Map map){
		List<Criterion> result = new LinkedList<>();
		List<Criterion> list;
		for (Object o : map.keySet()) {
			String key = o.toString();
			Object val = map.get(key);
			switch (key) {
				case "_in":  //范围之中
					list = getCriterionForIn((Map) val);
					break;
				case "_gt":  //大于
					list = getCriterionForGt((Map) val);
					break;
				case "_ge":  //大于等于
					list = getCriterionForGe((Map) val);
					break;
				case "_lt":   //小于
					list = getCriterionForLt((Map) val);
					break;
				case "_le":   //小于等于
					list = getCriterionForLe((Map) val);
					break;
				case "_and": //逻辑与
					list = getCriterionForAndOr((List) val);
					break;
				case "_or":  //逻辑或
					List<Criterion> list2 = getCriterionForAndOr((List) val);
					list = Collections.singletonList(Query.or(list2.toArray(new Criterion[0])));
					break;
				case "_like": //模糊查询
					list = getCriterionForLike((Map) val);
					break;
				default:     //等于
					list = Collections.singletonList(Query.equals(key, val.toString()));
			}
			result.addAll(list);
		}
		return result;
	}

	private static List<Criterion> getCriterionForAndOr(List list){
		List<Criterion> result = new LinkedList<>();
		for(Object obj:list){
			result.addAll(getCriterions((Map)obj));
		}
		return result;
	}

	private static List<Criterion> getCriterionForLike(Map map){
		List<Criterion> result = new LinkedList<>();
		for (Object o : map.keySet()) {
			String key = o.toString();
			String value = map.get(key).toString().replaceAll("[*]", "%").replaceAll("[?]", "_");
			result.add(Query.like(key, value));
		}
		return result;
	}

	private static List<Criterion> getCriterionForLe(Map map){
		List<Criterion> result = new LinkedList<>();
		for (Object o : map.keySet()) {
			String key = o.toString();
			Object value = map.get(key);
			result.add(Query.le(key, value));
		}
		return result;
	}
	
	private static List<Criterion> getCriterionForLt(Map map){
		List<Criterion> result = new LinkedList<>();
		for (Object o : map.keySet()) {
			String key = o.toString();
			Object value = map.get(key);
			result.add(Query.lt(key, value));
		}
		return result;
	}
	
	private static List<Criterion> getCriterionForGe(Map map){
		List<Criterion> result = new LinkedList<>();
		for (Object o : map.keySet()) {
			String key = o.toString();
			Object value = map.get(key);
			result.add(Query.ge(key, value));
		}
		return result;
	}
	
	private static List<Criterion> getCriterionForGt(Map map){
		List<Criterion> result = new LinkedList<>();
		for (Object o : map.keySet()) {
			String key = o.toString();
			Object value = map.get(key);
			result.add(Query.gt(key, value));
		}
		return result;
	}
	
	private static List<Criterion> getCriterionForIn(Map map){
		List<Criterion> result = new LinkedList<>();
		for (Object o : map.keySet()) {
			String key = o.toString();
			List value = (List) map.get(key);
			result.add(Query.in(key, value));
		}
		return result;
	}
	
	/**
	 * 从HTTP请求中取得{@linkplain studio.xiaoyun.web.PublicParameter#ROWS rows}的值
	 * @param request HTTP请求
	 * @return 最多返回的记录的数量
	 */
	public static int getRows(HttpServletRequest request){
		int rows = getInt(request,PublicParameter.ROWS.value(),20);
		rows = rows<1||rows>1000?20:rows;
		return rows;
	}

	/**
	 * 从HTTP请求中取得{@linkplain studio.xiaoyun.web.PublicParameter#SORT sort}的值。
	 * <p>输入格式为&lt;fieldName&gt; &lt;asc|desc&gt;[,&lt;fieldName&gt; &lt;asc|desc&gt;]...，
	 * 例如：“name desc,text asc”表示先以name降序排序，再以text升序排序
	 * @param request HTTP请求
	 * @return 排序参数, Object数组的第一个表示排序字段，String类型; 第二个表示是否升序，Boolean类型。如果没有数据，则返回空列表
	 */
	public static List<Object[]> getSortFields(HttpServletRequest request){
		List<Object[]> result = new LinkedList<>();
		String value = request.getParameter(PublicParameter.SORT.value());
		if(value!=null){
			if(value.matches("[0-9a-zA-Z_]+ (asc|desc)(,[0-9a-zA-Z_]+ (asc|desc))*")){
				String[] sorts = value.split(",");
				for(String sort:sorts){
					String[] s = sort.split(" ");
					Object[] o = new Object[2];
					o[0] = s[0];
					o[1] = "asc".equals(s[1]);
					result.add(o);
				}
			}else{
				throw new InvalidParameterException("参数"+PublicParameter.SORT.value()+"的格式错误:"+value);
			}
		}
		return result;
	}
	
	/**
	 * 从HTTP请求中取得{@linkplain studio.xiaoyun.web.PublicParameter#START start}的值。
	 * <p>参数{@linkplain studio.xiaoyun.web.PublicParameter#PAGE page}会转换为{@linkplain studio.xiaoyun.web.PublicParameter#START start}
	 * @param request HTTP请求
	 * @return 开始记录
	 */
	public static int getStart(HttpServletRequest request){
		int start = getInt(request,PublicParameter.START.value(),0);
		Integer page = getInt(request,PublicParameter.PAGE.value(),null);
		int rows = getRows(request);
		if(page!=null){
			start = (page-1)*rows;
		}
		start = start<0?0:start;
		return start;
	}

	/**
	 * 从请求中获得String类型的参数
	 * @param request HTTP请求
	 * @param parameterName 参数名
	 * @param defaultValue 默认值
	 * @return 参数的值，如果参数不存在，则返回默认值
	 */
	public static String getString(HttpServletRequest request,String parameterName,String defaultValue){
		String value = request.getParameter(parameterName);
		if(value==null){
			return defaultValue;
		}else{
			return value;
		}
	}

}
