package studio.xiaoyun.web;

import studio.xiaoyun.common.exception.ErrorCode;

import java.util.LinkedList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

/**
 * 封装http响应中的异常信息
 */
@XmlRootElement(name = "error")
public class HttpError {
	/**
	 * 异常信息
	 */
	private String message;
	/**
	 * 异常堆栈
	 */
	private List<String> stack;
	/**
	 * 错误码
	 */
	private ErrorCode code;

	@XmlElement
	public ErrorCode getCode() {
		return code;
	}

	public void setCode(ErrorCode code) {
		this.code = code;
	}

	@XmlElement
	public String getMessage() {
		return message;
	}
	
	@XmlJavaTypeAdapter(ListXMLAdapter.class)
	@XmlElement
	public List<String> getStack() {
		return stack;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}
	
	public void setStack(Exception exception) {
		stack = new LinkedList<>();
		stack.add(exception.getClass().getName());
		StackTraceElement[] elements = exception.getStackTrace();
		for(int i=0;i<elements.length;i++){
			String line = elements[i].getClassName()+"#"+elements[i].getMethodName()+"(line:"+elements[i].getLineNumber()+")";
			stack.add(line);
			if(i>13){
				break;
			}
		}
	}

}
