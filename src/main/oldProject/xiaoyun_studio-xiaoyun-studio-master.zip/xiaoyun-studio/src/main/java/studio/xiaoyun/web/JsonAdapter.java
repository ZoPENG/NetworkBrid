package studio.xiaoyun.web;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import studio.xiaoyun.common.tool.JsonTool;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class JsonAdapter extends JsonSerializer<HttpResponse> {

	@Override
	public void serialize(HttpResponse httpResponse, JsonGenerator jsonGenerator,
			SerializerProvider serializerProvider) throws IOException {
		Map<String,Object> map = new HashMap<>();
		map.put("total", httpResponse.getTotal());
		map.put("rows", httpResponse.getRows());
		if(httpResponse.getError() != null){
			map.put("error", httpResponse.getError());
		}
		String str = JsonTool.objectToString(map);
		jsonGenerator.writeRaw(str);
	}

}
