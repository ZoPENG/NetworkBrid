package studio.xiaoyun.core.dao;

import java.util.List;

import studio.xiaoyun.core.entity.FeedbackEntity;
import studio.xiaoyun.core.parameter.FeedbackParameter;

/**
 * 意见反馈
 */
public interface IFeedbackDao extends IBaseDao<FeedbackEntity> {
	
	/**
	 * 根据参数获得意见反馈的数量
	 * @param feedbackParameter 参数
	 * @return 数量
	 * @since 1.0.0
	 */
	public long getFeedbackCountByParameter(FeedbackParameter feedbackParameter);
	
	/**
	 * 根据参数获得意见反馈的列表
	 * @param feedbackParameter 参数
	 * @return 意见反馈的列表
	 * @since 1.0.0
	 */
	public List<FeedbackEntity> getFeedbacksByParameter(FeedbackParameter feedbackParameter);

}
