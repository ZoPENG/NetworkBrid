package studio.xiaoyun.core.dao.impl;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;
import studio.xiaoyun.common.exception.InvalidParameterException;
import studio.xiaoyun.common.exception.XysException;
import studio.xiaoyun.core.dao.IUserDao;
import studio.xiaoyun.core.entity.RoleEntity;
import studio.xiaoyun.core.entity.UserEntity;
import studio.xiaoyun.core.parameter.UserParameter;

import java.util.List;
import java.util.Optional;

@Repository("userDao")
public class UserDao extends BaseDao<UserEntity> implements IUserDao{

    @Override
    public UserEntity getById(String id) throws InvalidParameterException {
        UserEntity user = getSession().get(UserEntity.class,id);
        if(user==null){
            throw new InvalidParameterException(id+"不存在");
        }
        return user;
    }

    @Override
    public UserEntity loadById(String ID) {
        return getSession().load(UserEntity.class,ID);
    }

    @Override
    public Optional<UserEntity> getUserByName(String name) {
        Optional<UserEntity> user;
        String hql = "from UserEntity where name=:name";
        Query query = getSession().createQuery(hql);
        query.setParameter("name",name);
        List<UserEntity> list = query.list();
        if(list.size()>1){
            throw new XysException("根据用户名:"+name+"获得的结果不止一个！");
        }else if(list.size()==1){
            user = Optional.of(list.get(0));
        }else{
            user = Optional.empty();
        }
        return user;
    }

    @Override
    public Optional<UserEntity> getUserByEmail(String email) {
        Optional<UserEntity> user;
        String hql = "from UserEntity where email=:email";
        Query query = getSession().createQuery(hql);
        query.setParameter("email",email);
        List<UserEntity> list = query.list();
        if(list.size()>1){
            throw new XysException("根据邮箱:"+email+"获得的结果不止一个！");
        }else if(list.size()==1){
            user = Optional.of(list.get(0));
        }else{
            user = Optional.empty();
        }
        return user;
    }

    @Override
    public long getUserCountByParameter(UserParameter parameter) {
        return getCountByParameter(null,null,parameter);
    }

    @Override
    public List<UserEntity> getUsersByParameter(UserParameter parameter) {
        return getListByParameter(null,null,parameter,UserEntity.class);
    }

    @Override
    String getQuerySql() {
        return "select user_0.* from user as user_0";
    }

}
