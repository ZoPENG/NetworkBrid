package studio.xiaoyun.core.dao;


import studio.xiaoyun.core.entity.RoleEntity;
import studio.xiaoyun.core.entity.UserEntity;
import studio.xiaoyun.core.parameter.UserParameter;

import java.util.List;
import java.util.Optional;

/**
 * 用户
 */
public interface IUserDao extends IBaseDao<UserEntity>  {

    /**
     * 根据用户名获得用户信息
     * @param name 用户名
     * @return 用户信息
     */
    Optional<UserEntity> getUserByName(String name);

    /**
     * 根据邮箱判断用户是否存在
     * @param email 邮箱
     * @return 用户信息
     */
    Optional<UserEntity> getUserByEmail(String email);

    /**
     * 获得用户的数量
     * @param parameter 搜索参数
     * @return 用户的数量
     */
    long getUserCountByParameter(UserParameter parameter);

    /**
     * 搜索用户
     * @param parameter 搜索参数
     * @return 用户列表
     */
    List<UserEntity> getUsersByParameter(UserParameter parameter);

}
