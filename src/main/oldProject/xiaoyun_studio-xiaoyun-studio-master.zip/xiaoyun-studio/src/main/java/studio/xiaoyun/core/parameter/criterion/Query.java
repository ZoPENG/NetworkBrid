package studio.xiaoyun.core.parameter.criterion;

import java.util.Collection;

/**
 * 封装查询条件中的各种运算符。
 * <p>例如：大于、小于、等于</p>
 */
public final class Query {
	
	/**
	 * 逻辑与
	 * @param criterions 搜索条件
	 * @return Criterion实例
	 * @since 1.0.0
	 */
	public static Criterion and(Criterion... criterions) {
		return new CriterionAnd(criterions);
	}

	/**
	 * 等于
	 * @param propertyName  属性名
	 * @param value 值
	 * @return Criterion实例
	 * @since 1.0.0
	 */
	public static Criterion equals(String propertyName, Object value) {
		return new CriterionEquals(propertyName,value);
	}

	/**
	 * 大于等于
	 * @param propertyName  属性名
	 * @param value 值
	 * @return Criterion实例
	 * @since 1.0.0  
	 */
	public static Criterion ge(String propertyName, Object value) {
		return new CriterionGe(propertyName,value);
	}

	/**
	 * 大于
	 * @param propertyName  属性名
	 * @param value 值
	 * @return Criterion实例
	 * @since 1.0.0
	 */
	public static Criterion gt(String propertyName, Object value) {
		return new CriterionGt(propertyName,value);
	}

	/**
	 * 范围查询
	 * @param propertyName  属性名
	 * @param values 值
	 * @return Criterion实例
	 * @since 1.0.0
	 */
	public static Criterion in(String propertyName, Collection<?> values) {
		return new CriterionIn(propertyName,values);
	}

	/**
	 * 小于等于
	 * @param propertyName  属性名
	 * @param value 值
	 * @return Criterion实例
	 * @since 1.0.0
	 */
	public static Criterion le(String propertyName, Object value) {
		return new CriterionLe(propertyName,value);
	}

	/**
	 * 模糊查询
	 * <br/>支持占位符‘%’、'_'
	 * @param propertyName  属性名
	 * @param value 值
	 * @return Criterion实例
	 * @since 1.0.0
	 */
	public static Criterion like(String propertyName, Object value) {
		return new CriterionLike(propertyName,value);
	}

	/**
	 * 小于
	 * @param propertyName  属性名
	 * @param value 值
	 * @return Criterion实例
	 * @since 1.0.0
	 */
	public static Criterion lt(String propertyName, Object value) {
		return new CriterionLt(propertyName,value);
	}

	/**
	 * 不等于
	 * @param propertyName 属性名
	 * @param value 值
	 * @return Criterion实例
	 * @since 1.0.0
	 */
	public static Criterion notEquals(String propertyName, Object value){
		return new CriterionNotEquals(propertyName,value);
	}

	/**
	 * 逻辑或
	 * @param criterions Criterion实例
	 * @return Criterion实例
	 * @since 1.0.0
	 */
	public static Criterion or(Criterion... criterions) {
		return new CriterionOr(criterions);
	}
	
	private Query() {}

}
