package studio.xiaoyun.core.dao;

import studio.xiaoyun.core.entity.RoleEntity;
import studio.xiaoyun.core.parameter.RoleParameter;

import javax.management.relation.Role;
import java.util.List;
import java.util.Optional;

/**
 * 角色
 */
public interface IRoleDao extends IBaseDao<RoleEntity>{

    /**
     * 获得角色的数量
     * @param parameter 搜索参数
     * @return 角色的数量
     */
    long getRoleCountByParameter(RoleParameter parameter);

    /**
     * 搜索角色
     * @param parameter 搜索参数
     * @return 角色列表
     */
    List<RoleEntity> getRolesByParameter(RoleParameter parameter);

    /**
     * 根据用户id获得该用户拥有的角色的数量
     * @param userId 用户id
     * @param parameter 搜索参数
     * @return 用户拥有的角色的数量
     */
    long getRoleCountByUserId(String userId,RoleParameter parameter);

    /**
     * 根据用户id获得该用户拥有的角色
     * @param userId 用户id
     * @param parameter 搜索参数
     * @return 用户拥有的角色
     */
    List<RoleEntity> getRolesByUserId(String userId,RoleParameter parameter);

}
