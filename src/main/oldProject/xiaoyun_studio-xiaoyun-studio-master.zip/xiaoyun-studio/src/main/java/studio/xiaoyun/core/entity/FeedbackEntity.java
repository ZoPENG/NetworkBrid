package studio.xiaoyun.core.entity;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

/**
 * 意见反馈
 * @author 岳正灵
 * @version 1.0.0
 */
@Entity
@Table(name = "feedback")
public class FeedbackEntity {

	@Id
	@GeneratedValue(generator = "idGenerator")
	@GenericGenerator(name = "idGenerator", strategy = "studio.xiaoyun.core.dao.UuidIdentifierGenerator")
	@Column(length = 32)
	private String feedbackId;
	/**
	 * 标题
	 */
	@Column(length = 50, nullable = false)
	private String title;
	/**
	 * 文字
	 */
	@Column(length = 255, nullable = false)
	private String text;
	/**
	 * 创建日期
	 */
	@Column(nullable = false)
	private Date createDate = new Date();
	
	public Date getCreateDate() {
		return createDate;
	}


	public String getText() {
		return text;
	}

	public String getTitle() {
		return title;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}


	public void setText(String text) {
		this.text = text;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getFeedbackId() {
		return feedbackId;
	}

	public void setFeedbackId(String feedbackId) {
		this.feedbackId = feedbackId;
	}
}
