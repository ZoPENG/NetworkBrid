package studio.xiaoyun.common.exception;

/**
 * 当客户端提供的参数无效时抛出该异常，内部方法调用时的参数错误不应该抛出该异常
 */
public class InvalidParameterException extends XysException{
    private static final long serialVersionUID = -2097465532154739597L;

    public InvalidParameterException(String message) {
        super(ErrorCode.PARAMETER_ERROR,message);
    }
}
