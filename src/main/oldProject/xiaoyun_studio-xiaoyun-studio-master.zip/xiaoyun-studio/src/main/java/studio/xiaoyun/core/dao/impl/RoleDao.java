package studio.xiaoyun.core.dao.impl;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;
import studio.xiaoyun.common.exception.InvalidParameterException;
import studio.xiaoyun.common.exception.XysException;
import studio.xiaoyun.core.dao.IRoleDao;
import studio.xiaoyun.core.entity.RoleEntity;
import studio.xiaoyun.core.parameter.RoleParameter;

import java.util.List;
import java.util.Optional;

@Repository("roleDao")
public class RoleDao extends BaseDao<RoleEntity> implements IRoleDao{

    @Override
    public RoleEntity getById(String id) throws InvalidParameterException {
        RoleEntity role = getSession().get(RoleEntity.class,id);
        if(role==null){
            throw new InvalidParameterException(id+"不存在");
        }
        return role;
    }

    @Override
    public RoleEntity loadById(String id) {
        return getSession().load(RoleEntity.class,id);
    }

    @Override
    String getQuerySql() {
        return "select role_0.* from role as role_0";
    }

    @Override
    public long getRoleCountByParameter(RoleParameter parameter) {
        return getCountByParameter(null,null,parameter);
    }

    @Override
    public List<RoleEntity> getRolesByParameter(RoleParameter parameter) {
        return getListByParameter(null,null,parameter,RoleEntity.class);
    }

    @Override
    public long getRoleCountByUserId(String userId, RoleParameter parameter) {
        String table = "join user_role as user_role_0 on user_role_0.roleId=role_0.roleId";
        String where = "user_role_0.userId='"+userId+"'";
        return getCountByParameter(table,where,parameter);
    }

    @Override
    public List<RoleEntity> getRolesByUserId(String userId, RoleParameter parameter) {
        String table = "join user_role as user_role_0 on user_role_0.roleId=role_0.roleId";
        String where = "user_role_0.userId='"+userId+"'";
        return getListByParameter(table,where,parameter,RoleEntity.class);
    }
}
