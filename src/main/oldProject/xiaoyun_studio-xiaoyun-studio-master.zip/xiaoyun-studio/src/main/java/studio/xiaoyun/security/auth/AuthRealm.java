package studio.xiaoyun.security.auth;

import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import studio.xiaoyun.core.dao.IPermissionDao;
import studio.xiaoyun.core.dao.IRoleDao;
import studio.xiaoyun.core.dao.IUserDao;
import studio.xiaoyun.core.entity.PermissionEntity;
import studio.xiaoyun.core.entity.RoleEntity;
import studio.xiaoyun.core.entity.UserEntity;

import java.util.List;
import java.util.Optional;

public class AuthRealm extends AuthorizingRealm {
    private IUserDao userDao;
    private IRoleDao roleDao;
    private IPermissionDao permissionDao;

    public IRoleDao getRoleDao() {
        return roleDao;
    }

    public void setRoleDao(IRoleDao roleDao) {
        this.roleDao = roleDao;
    }

    public IPermissionDao getPermissionDao() {
        return permissionDao;
    }

    public void setPermissionDao(IPermissionDao permissionDao) {
        this.permissionDao = permissionDao;
    }

    public IUserDao getUserDao() {
        return userDao;
    }

    public void setUserDao(IUserDao userDao) {
        this.userDao = userDao;
    }

    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection pc) {
        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
        String userId = (String) pc.fromRealm(this.getName()).iterator().next();
        //获得用户的所有权限
        List<PermissionEntity> permissions = permissionDao.getPermissionsByUserId(userId, null);
        for (PermissionEntity permission : permissions) {
            info.addStringPermission(permission.getName().name());
        }
        //获得用户的所有角色
        List<RoleEntity> roles = roleDao.getRolesByUserId(userId, null);
        for (RoleEntity role : roles) {
            info.addRole(role.getName());
        }
        return info;
    }

    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken)
            throws AuthenticationException {
        UsernamePasswordToken token = (UsernamePasswordToken) authenticationToken;
        Optional<UserEntity> user = userDao.getUserByEmail(token.getUsername());
        if (!user.isPresent()) { //如果根据邮箱无法找到用户，则根据用户名查找
            user = userDao.getUserByName(token.getUsername());
        }
        if (!user.isPresent()) {
            throw new UnknownAccountException();  //用户名或者邮箱不存在
        }
        UserEntity userInfo = user.get();
        //检查用户的状态
        switch (userInfo.getStatus()) {
            case NORMAL:
                break;
            case DELETED:
                throw new DisabledAccountException();  //账号不可用
            default:
                throw new AccountException("无法识别的参数:" + userInfo.getStatus());  //内部错误
        }
        //检查用户类型
        if(!userInfo.getType().equals(token.getType())){
            throw new UnknownAccountException();
        }
        return new SimpleAuthenticationInfo(userInfo.getUserId(), userInfo.getPassword(), this.getName());
    }

}
