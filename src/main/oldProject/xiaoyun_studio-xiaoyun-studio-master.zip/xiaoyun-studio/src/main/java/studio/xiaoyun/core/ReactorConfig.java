package studio.xiaoyun.core;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import reactor.Environment;
import reactor.bus.EventBus;
import reactor.spring.context.config.EnableReactor;

@Configuration
@EnableReactor
public class ReactorConfig {

    @Bean(name="eventBus")
    public EventBus createEventBus(){
        Environment environment = new Environment();
        return EventBus.create(environment);
    }

}
