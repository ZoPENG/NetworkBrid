package studio.xiaoyun.web.resource;

/**
 * 该接口用来表示一个类是用来封装客户端数据的
 */
public interface Resource{

}
