package studio.xiaoyun.core.dao;

import studio.xiaoyun.core.entity.PermissionEntity;
import studio.xiaoyun.core.parameter.PermissionParameter;

import java.util.List;

/**
 * 权限相关
 */
public interface IPermissionDao extends IBaseDao<PermissionEntity>{

    /**
     * 获得权限信息
     * @param parameter 搜索参数
     * @return 权限
     */
    List<PermissionEntity> getPermissionsByParameter(PermissionParameter parameter);

    /**
     * 权限的数量
     * @param parameter　搜索参数
     * @return 权限的数量
     */
    long getPermissionCountByParameter(PermissionParameter parameter);

    /**
     * 根据用户Id获得该用户的权限
     * @param userId 用户Id
     * @param parameter 搜索参数
     * @return 用户的权限
     */
    List<PermissionEntity> getPermissionsByUserId(String userId, PermissionParameter parameter);

    /**
     * 根据用户Id获得该用户的权限的数量
     * @param userId　用户Id
     * @param parameter　搜索参数
     * @return 该用户的权限的数量
     */
    long getPermissionCountByUserId(String userId, PermissionParameter parameter);

    /**
     * 根据角色Id获得该角色的权限
     * @param roleId 角色Id
     * @param parameter 搜索参数
     * @return 角色的权限
     */
    List<PermissionEntity> getPermissionsByRoleId(String roleId, PermissionParameter parameter);

    /**
     * 根据角色Id获得该角色的权限的数量
     * @param roleId　角色Id
     * @param parameter　搜索参数
     * @return 该角色的权限的数量
     */
    long getPermissionCountByRoleId(String roleId, PermissionParameter parameter);

}
