package studio.xiaoyun.core.service.impl;

import org.springframework.stereotype.Service;
import studio.xiaoyun.core.dao.IUserDao;
import studio.xiaoyun.core.constant.UserStatus;
import studio.xiaoyun.core.entity.UserEntity;
import studio.xiaoyun.core.service.IUserService;

import javax.annotation.Resource;
import java.util.Date;

@Service
public class UserService implements IUserService {
    @Resource
    private IUserDao userDao;

    @Override
    public String createUser( String email, String password) {
        UserEntity user = new UserEntity();
        user.setPassword(password);
        user.setEmail(email);
        user.setCreateDate(new Date());
        user.setStatus(UserStatus.NORMAL);
        String userID = userDao.save(user);
        user.setName("网友"+userID);
        return userID;
    }
}
