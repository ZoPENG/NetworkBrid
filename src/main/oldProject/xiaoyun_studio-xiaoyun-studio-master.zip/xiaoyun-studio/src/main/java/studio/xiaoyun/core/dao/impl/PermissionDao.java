package studio.xiaoyun.core.dao.impl;

import org.springframework.stereotype.Repository;
import studio.xiaoyun.common.exception.InvalidParameterException;
import studio.xiaoyun.core.dao.IPermissionDao;
import studio.xiaoyun.core.entity.PermissionEntity;
import studio.xiaoyun.core.parameter.PermissionParameter;

import java.util.List;
import java.util.Optional;

@Repository("permissionDao")
public class PermissionDao extends BaseDao<PermissionEntity> implements IPermissionDao {

    @Override
    public PermissionEntity getById(String id) throws InvalidParameterException {
        PermissionEntity permission = getSession().get(PermissionEntity.class, id);
        if(permission==null){
            throw new InvalidParameterException(id+"不存在");
        }
        return permission;
    }

    @Override
    public PermissionEntity loadById(String id) {
        return getSession().load(PermissionEntity.class, id);
    }

    @Override
    public List<PermissionEntity> getPermissionsByParameter(PermissionParameter parameter) {
        return getListByParameter(null,null,parameter,PermissionEntity.class);
    }

    @Override
    public long getPermissionCountByParameter(PermissionParameter parameter) {
        return getCountByParameter(null,null,parameter);
    }

    @Override
    public List<PermissionEntity> getPermissionsByUserId(String userId, PermissionParameter parameter) {
        StringBuilder where = new StringBuilder();
        where.append("permission_0.permissionId in (SELECT a.permissionId FROM permission AS a JOIN user_permission");
        where.append(" AS b ON a.permissionId = b.permissionId WHERE b.userId ='").append(userId);
        where.append("' union SELECT a.permissionId FROM permission AS a JOIN role_permission AS b ON ");
        where.append("a.permissionId = b.permissionId JOIN user_role AS c ON b.roleId = c.roleId WHERE c.userId ='");
        where.append(userId).append("')");
        return getListByParameter(null,where.toString(),parameter,PermissionEntity.class);
    }

    @Override
    public long getPermissionCountByUserId(String userId, PermissionParameter parameter) {
        StringBuilder where = new StringBuilder();
        where.append("permission_0.permissionId in (SELECT a.permissionId FROM permission AS a JOIN user_permission");
        where.append(" AS b ON a.permissionId = b.permissionId WHERE b.userId ='").append(userId);
        where.append("' union SELECT a.permissionId FROM permission AS a JOIN role_permission AS b ON ");
        where.append("a.permissionId = b.permissionId JOIN user_role AS c ON b.roleId = c.roleId WHERE c.userId ='");
        where.append(userId).append("')");
        return getCountByParameter(null,where.toString(),parameter);
    }

    @Override
    public List<PermissionEntity> getPermissionsByRoleId(String roleId, PermissionParameter parameter) {
        String table = "join role_permission as role_permission_0 on permission_0.permissionId=role_permission_0.permissionId";
        String where = "role_permission_0.roleId='"+roleId+"'";
        return getListByParameter(table,where,parameter,PermissionEntity.class);
    }

    @Override
    public long getPermissionCountByRoleId(String roleId, PermissionParameter parameter) {
        String table = "join role_permission as role_permission_0 on permission_0.permissionId=role_permission_0.permissionId";
        String where = "role_permission_0.roleId='"+roleId+"'";
        return getCountByParameter(table,where,parameter);
    }

    @Override
    String getQuerySql() {
        return "select permission_0.* from permission as permission_0";
    }

}
