package studio.xiaoyun.web;

import java.util.Collections;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonSerialize(using = JsonAdapter.class)
@XmlRootElement(name = "response")
public class HttpResponse {

	/**
	 * 总数
	 */
	private Long total;
	/**
	 * 行
	 */
	@SuppressWarnings("rawtypes")
	private List rows;
	/**
	 * 异常信息
	 */
	private HttpError error;

	@XmlElement
	public Long getTotal() {
		return total==null?0L:total;
	}

	public void setTotal(Long total) {
		this.total = total;
	}

	@SuppressWarnings("rawtypes")
	@XmlJavaTypeAdapter(ListXMLAdapter.class)
	@XmlElement
	public List getRows() {
		return rows == null ? Collections.emptyList() : rows;
	}

	@SuppressWarnings("rawtypes")
	public void setRows(List rows) {
		this.rows = rows;
	}
	
	/**
	 * 取得封装的异常信息
	 * @return 异常信息，可能为null
	 */
	@XmlElement
	public HttpError getError() {
		return error;
	}

	public void setError(HttpError error) {
		this.error = error;
	}
}
