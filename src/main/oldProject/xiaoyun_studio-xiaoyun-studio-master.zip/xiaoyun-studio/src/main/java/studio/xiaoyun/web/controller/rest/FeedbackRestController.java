package studio.xiaoyun.web.controller.rest;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import studio.xiaoyun.common.exception.InvalidParameterException;
import studio.xiaoyun.core.constant.Permission;
import studio.xiaoyun.core.dao.IFeedbackDao;
import studio.xiaoyun.core.entity.FeedbackEntity;
import studio.xiaoyun.core.parameter.FeedbackParameter;
import studio.xiaoyun.core.service.IFeedbackService;
import studio.xiaoyun.security.annotation.RequirePermission;
import studio.xiaoyun.web.ParameterUtil;
import studio.xiaoyun.web.ResourceUtil;
import studio.xiaoyun.web.RestResult;
import studio.xiaoyun.web.resource.FeedbackResource;

/**
 * 意见反馈的控制器
 * @author 岳正灵
 * @since 1.0.0
 */
@RestController
@RequestMapping("/v1/feedback")
public class FeedbackRestController {
	@Resource
	private IFeedbackDao feedbackDao;
	@Resource
	private ResourceUtil resourceUtil;
	@Resource
	private IFeedbackService feedbackService;
	
	/**
	 * 创建一个意见反馈
	 * @param title 标题
	 * @param text 文字
	 * @return 新创建的意见反馈
	 */
	@ResponseStatus(HttpStatus.CREATED)
	@RequestMapping(value = "", method = RequestMethod.PUT)
	public RestResult createFeedback(String title,String text){
		String id = feedbackService.createFeedback(title, text);
		FeedbackEntity feedback = feedbackDao.getById(id);
		List<FeedbackResource> resource = resourceUtil.toResource(Collections.singletonList(feedback),null,FeedbackResource.class);
		return new RestResult(1L,resource);
	}
	
	/**
	 * 根据ID删除数据
	 * @param feedbackId 意见反馈的Id
	 */
	@RequirePermission(Permission.FEEDBACK_DELETE_BY_ID)
	@ResponseStatus(HttpStatus.NO_CONTENT)
	@RequestMapping(value = "/{id:\\S{32}}", method = RequestMethod.DELETE)
	public void deleteFeedbackById(@PathVariable("id") String feedbackId){
		feedbackDao.delete(feedbackId);
	}
	
	/**
	 * 根据ID获得意见反馈
	 * @param request HTTP请求
	 * @param feedbackId ID
	 * @return 意见反馈
	 * @throws InvalidParameterException 如果根据id没有找到，则抛出异常
	 */
	@RequestMapping(value = "/{Id:\\S{32}}", method = RequestMethod.GET)
	public RestResult getFeedbackByID(HttpServletRequest request,@PathVariable("Id") String feedbackId)throws InvalidParameterException{
		FeedbackParameter param = ParameterUtil.getParameter(request, FeedbackParameter.class);
		FeedbackEntity feedback = feedbackDao.getById( feedbackId);
		List<FeedbackResource> resource = resourceUtil.toResource(Collections.singletonList(feedback),param,FeedbackResource.class);
		long total = 1;
		return new RestResult(total,resource);
	}
	
	/**
	 * 根据参数获得意见反馈的列表
	 * @param request http请求
	 * @return 意见反馈的列表
	 * @see studio.xiaoyun.core.parameter.FeedbackParameter 意见反馈的参数类
	 */
	@RequirePermission(Permission.FEEDBACK_GET_ALL)
	@RequestMapping(value = "", method = RequestMethod.GET)
	public RestResult getFeedbackByParameter(HttpServletRequest request){
		FeedbackParameter param = ParameterUtil.getParameter(request, FeedbackParameter.class);
		long count = feedbackDao.getFeedbackCountByParameter(param);
		List<FeedbackEntity> feedbackList = feedbackDao.getFeedbacksByParameter(param);
		List<FeedbackResource> resourceList = resourceUtil.toResource(feedbackList,param,FeedbackResource.class);
		return new RestResult(count,resourceList);
	}

}
