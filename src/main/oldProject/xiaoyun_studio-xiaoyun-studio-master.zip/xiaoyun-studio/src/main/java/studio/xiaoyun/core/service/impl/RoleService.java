package studio.xiaoyun.core.service.impl;

import org.springframework.stereotype.Service;
import studio.xiaoyun.common.exception.InvalidParameterException;
import studio.xiaoyun.core.dao.IPermissionDao;
import studio.xiaoyun.core.dao.IRoleDao;
import studio.xiaoyun.core.entity.PermissionEntity;
import studio.xiaoyun.core.entity.RoleEntity;
import studio.xiaoyun.core.parameter.PermissionParameter;
import studio.xiaoyun.core.parameter.criterion.Query;
import studio.xiaoyun.core.service.IRoleService;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 角色相关
 */
@Service
public class RoleService implements IRoleService{
    @Resource
    private IRoleDao roleDao;
    @Resource
    private IPermissionDao permissionDao;

    @Override
    public void setRolePermission(String roleId, Set<String> permissionIds) {
        RoleEntity role = roleDao.getById(roleId);
        Set<PermissionEntity> permissionSet;
        if(permissionIds==null || permissionIds.isEmpty()){
            permissionSet = Collections.emptySet();
        }else{
            PermissionParameter params = new PermissionParameter();
            params.addQuery(Query.in("permissionId",permissionIds));
            List<PermissionEntity> permissionList = permissionDao.getPermissionsByParameter(params);
            if(permissionIds.size()!=permissionList.size()){
                throw new InvalidParameterException("权限id不存在");
            }
            permissionSet = permissionList.stream().collect(Collectors.toSet());
        }
        role.setPermissions(permissionSet);
        roleDao.update(role);
    }

}
