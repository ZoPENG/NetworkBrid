package studio.xiaoyun.web;

/**
 * 定义HTTP请求中通用的请求参数的名称
 */
public enum PublicParameter {
	/**
	 * 开始记录，从0开始的整数
	 */
	START("start"), 
	/**
	 * 页数，从1开始的整数
	 */
	PAGE("page"), 
	/**
	 * 最多返回记录的数量，从1开始的整数
	 */
	ROWS("rows"), 
	/**
	 * 返回结果中应该包含的字段
	 */
	FIELD("field"), 
	/**
	 * HTTP方法
	 */
	METHOD("method"), 
	/**
	 * 媒体类型
	 */
	FORMAT("format"), 
	/**
	 * 搜索条件
	 */
	QUERY("query"),
	/**
	 * 将搜索条件进行urlencode编码
	 */
	QUERY_ENCODE("query_encode"),
	/**
	 * 排序条件
	 */
	SORT("sort"),
	/**
	 * jsonp请求时使用该参数指定回调函数
	 */
	CALLBACK("callback");

	private final String name;

	PublicParameter(String name) {
		this.name = name;
	}

	/**
	 * 
	 * @return 通用参数的名称
	 */
	public String value() {
		return this.name;
	}

}
