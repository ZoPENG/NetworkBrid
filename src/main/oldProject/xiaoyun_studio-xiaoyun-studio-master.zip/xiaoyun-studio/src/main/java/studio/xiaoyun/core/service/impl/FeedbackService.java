package studio.xiaoyun.core.service.impl;

import java.util.Date;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import studio.xiaoyun.core.dao.IFeedbackDao;
import studio.xiaoyun.core.entity.FeedbackEntity;
import studio.xiaoyun.common.exception.XysException;
import studio.xiaoyun.common.exception.ErrorCode;
import studio.xiaoyun.core.service.IFeedbackService;

@Service
public class FeedbackService implements IFeedbackService {

	@Resource
	private IFeedbackDao feedbackDao;
	
	public IFeedbackDao getFeedbackDao() {
		return feedbackDao;
	}

	public void setFeedbackDao(IFeedbackDao feedbackDao) {
		this.feedbackDao = feedbackDao;
	}

	@Override
	public String createFeedback(String title, String text) {
		if(text==null || text.trim().length()==0){
			throw new XysException(ErrorCode.PARAMETER_ERROR,"内容不能为空!");
		}
		if(title==null || title.trim().length()==0){
			title = "网友";
		}
		FeedbackEntity feedback = new FeedbackEntity();
		feedback.setText(text.trim());
		feedback.setTitle(title.trim());
		feedback.setCreateDate(new Date());
		String id = feedbackDao.save(feedback);
        return id;
	}

}
