package studio.xiaoyun.web.resource;

import studio.xiaoyun.core.constant.UserStatus;

import java.util.Date;

public class UserResource implements Resource{
    private String userId;

    /**
     * 用户名
     */
    private String name;

    /**
     * 创建时间
     */
    private Date createDate;

    /**
     * 邮箱
     */
    private String email;

    /**
     * 用户状态
     */
    private UserStatus status;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public UserStatus getStatus() {
        return status;
    }

    public void setStatus(UserStatus status) {
        this.status = status;
    }
}
