package studio.xiaoyun.core.dao.impl;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.w3c.dom.Document;
import studio.xiaoyun.common.exception.XysException;
import studio.xiaoyun.core.constant.*;
import studio.xiaoyun.core.dao.IPermissionDao;
import studio.xiaoyun.core.dao.IRoleDao;
import studio.xiaoyun.core.dao.IUserDao;
import studio.xiaoyun.core.entity.PermissionEntity;
import studio.xiaoyun.core.entity.RoleEntity;
import studio.xiaoyun.core.entity.UserEntity;
import studio.xiaoyun.core.parameter.PermissionParameter;

import javax.annotation.Resource;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import java.io.File;
import java.net.URL;
import java.net.URLDecoder;
import java.util.*;

/**
 * 系统启动时初始化数据库
 */
@Repository
public class InitDatabase {
    private Logger logger = LoggerFactory.getLogger(InitDatabase.class);
    @Resource
    private SessionFactory sessionFactory;
    @Resource
    private IUserDao userDao;
    @Resource
    private IRoleDao roleDao;
    @Resource
    private IPermissionDao permissionDao;

    public void updateDatabase() {
        logger.debug("开始初始化数据库");
        try{
            initUser();
            initRole();
            initPermission();
            initUserRole();
            initAdminPermission();
        }catch(Exception e){
            logger.error("初始化数据库时出现错误",e);
        }
    }

    private void initUser() throws Exception{
        URL fileUrl = getClass().getClassLoader().getResource("data"+File.separator+"users.xml");
        if(fileUrl==null){
            logger.error("users.xml不存在，无法初始化系统用户");
            return;
        }
        String filePath = URLDecoder.decode(fileUrl.getFile(),"utf-8"); //防止文件路径中包含中文时出现乱码
        Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(filePath);
        XPath xpath = XPathFactory.newInstance().newXPath();
        List<String> list = new ArrayList<>();
        for (SystemUser systemUser : SystemUser.values()) {
            list.add(systemUser.getUserId());
        }
        String sql = "SELECT userId FROM user WHERE userId IN (:userId)";
        Session session = sessionFactory.getCurrentSession();
        SQLQuery query = session.createSQLQuery(sql);
        query.setParameterList("userId", list);
        //查询出数据库中已经存在的用户id
        List<String> list2 = query.list();
        Map<String,String> userIdMap = new HashMap<>();
        for (SystemUser systemUser : SystemUser.values()) {
            if (list2.contains(systemUser.getUserId())) continue;
            String email = (String)xpath.evaluate("/root/"+systemUser.getName()+"/email", document, XPathConstants.STRING);
            String password = (String)xpath.evaluate("/root/"+systemUser.getName()+"/password", document, XPathConstants.STRING);
            if(StringUtils.isBlank(email) || StringUtils.isBlank(password)){
                throw new XysException("users.xml中密码和邮箱不能为空");
            }
            UserEntity user = new UserEntity();
            user.setName(systemUser.getName());
            user.setEmail(email);
            user.setPassword(password);
            user.setStatus(UserStatus.NORMAL);
            user.setType(UserType.SYSTEM);
            user.setCreateDate(new Date());
            userDao.save(user);
            userIdMap.put(systemUser.getUserId(),user.getUserId());
        }
        //将自动生成的id改为预定义的id
        if(!userIdMap.isEmpty()){
            session.flush();
            session.clear();
            for(Map.Entry<String,String> entry:userIdMap.entrySet()){
                String updateSql = "update user set userId=? where userId=?";
                SQLQuery updateQuery = session.createSQLQuery(updateSql);
                updateQuery.setString(0,entry.getKey());
                updateQuery.setString(1,entry.getValue());
                updateQuery.executeUpdate();
            }
        }
        logger.debug("初始化系统用户完成");
    }



    private void initRole() {
        List<String> list = new ArrayList<>();
        for (SystemRole systemRole : SystemRole.values()) {
            list.add(systemRole.getRoleId());
        }
        String sql = "SELECT roleId FROM role WHERE roleId IN (:roleId)";
        Session session = sessionFactory.getCurrentSession();
        SQLQuery query = session.createSQLQuery(sql);
        query.setParameterList("roleId", list);
        List<String> list2 = query.list();
        Map<String,String> roleIdMap = new HashMap<>();
        for (SystemRole systemRole : SystemRole.values()) {
            if (list2.contains(systemRole.getRoleId())) continue;
            RoleEntity role = new RoleEntity();
            role.setName(systemRole.getName());
            role.setDescription(systemRole.getDescription());
            roleDao.save(role);
            roleIdMap.put(systemRole.getRoleId(),role.getRoleId());
        }
        //将自动生成的id改为预定义的id
        if(!roleIdMap.isEmpty()){
            session.flush();
            session.clear();
            for(Map.Entry<String,String> entry : roleIdMap.entrySet()){
                String updateSql = "update role set roleId=? where roleId=?";
                SQLQuery updateQuery = session.createSQLQuery(updateSql);
                updateQuery.setString(0,entry.getKey());
                updateQuery.setString(1,entry.getValue());
                updateQuery.executeUpdate();
            }
        }
        logger.debug("初始化系统角色完成");
    }

    private void initPermission(){
        List<String> list = new ArrayList<>();
        for (Permission permission : Permission.values()) {
            list.add(permission.name());
        }
        String sql = "select name from permission where name in (:name)";
        Session session = sessionFactory.getCurrentSession();
        SQLQuery query = session.createSQLQuery(sql);
        query.setParameterList("name", list);
        List<String> list2 = query.list();
        for(Permission permission:Permission.values()){
            if(list2.contains(permission.name())) continue;
            PermissionEntity entity = new PermissionEntity();
            entity.setName(permission);
            entity.setType(permission.getType());
            entity.setDescription(permission.getDescription());
            permissionDao.save(entity);
        }
        if(list2.size()!=Permission.values().length){
            session.flush();
            session.clear();
        }
        logger.debug("初始化系统权限完成");
    }

    /**
     * 初始化系统用户的角色
     */
    private void initUserRole(){
        //设置admin的角色
        UserEntity user = userDao.getById(SystemUser.ADMIN.getUserId());
        Set<RoleEntity> userRole = user.getRoles();
        if(!userRole.stream().anyMatch(item->item.getRoleId().equals(SystemRole.ADMIN.getRoleId()))){
            RoleEntity role = roleDao.getById(SystemRole.ADMIN.getRoleId());
            userRole.add(role);
            userDao.save(user);
        }
        //设置user的角色
        user = userDao.getById(SystemUser.USER.getUserId());
        userRole = user.getRoles();
        if(!userRole.stream().anyMatch(item->item.getRoleId().equals(SystemRole.USER.getRoleId()))){
            RoleEntity role = roleDao.getById(SystemRole.USER.getRoleId());
            userRole.add(role);
            userDao.save(user);
        }
        //设置public的角色
        user = userDao.getById(SystemUser.PUBLIC.getUserId());
        userRole = user.getRoles();
        if(!userRole.stream().anyMatch(item->item.getRoleId().equals(SystemRole.PUBLIC.getRoleId()))){
            RoleEntity role = roleDao.getById(SystemRole.PUBLIC.getRoleId());
            userRole.add(role);
            userDao.save(user);
        }
        logger.debug("初始化用户角色完成");
    }

    /**
     * 初始化管理员的权限
     */
    private void initAdminPermission(){
        RoleEntity role = roleDao.getById(SystemRole.ADMIN.getRoleId());
        Set<PermissionEntity> permissionSet = role.getPermissions();
        PermissionParameter params = new PermissionParameter();
        params.setMaxResults(1000);
        List<PermissionEntity> permissionList = permissionDao.getPermissionsByParameter(params);
        boolean isUpdate = false;
        for(PermissionEntity permission:permissionList){
            if(!permissionSet.contains(permission)){
                permissionSet.add(permission);
                isUpdate = true;
            }
        }
        if(isUpdate){
            roleDao.update(role);
        }
        logger.debug("初始化管理员权限完成");
    }

}
