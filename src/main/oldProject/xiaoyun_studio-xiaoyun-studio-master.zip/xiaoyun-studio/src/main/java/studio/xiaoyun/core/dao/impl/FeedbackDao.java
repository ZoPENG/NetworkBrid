package studio.xiaoyun.core.dao.impl;

import org.springframework.stereotype.Repository;
import studio.xiaoyun.common.exception.InvalidParameterException;
import studio.xiaoyun.core.dao.IFeedbackDao;
import studio.xiaoyun.core.entity.FeedbackEntity;
import studio.xiaoyun.core.parameter.FeedbackParameter;

import java.util.List;
import java.util.Optional;

@Repository("feedbackDao")
public class FeedbackDao extends BaseDao<FeedbackEntity> implements IFeedbackDao {

    @Override
    public FeedbackEntity getById(String id) throws InvalidParameterException {
        FeedbackEntity feedback = getSession().get(FeedbackEntity.class, id);
        if(feedback==null){
            throw new InvalidParameterException(id+"不存在");
        }
        return feedback;
    }

    @Override
    public FeedbackEntity loadById(String ID) {
        return getSession().load(FeedbackEntity.class, ID);
    }

    @Override
    public long getFeedbackCountByParameter(FeedbackParameter parameter) {
        return getCountByParameter(null,null,parameter);
    }

    @Override
    public List<FeedbackEntity> getFeedbacksByParameter(FeedbackParameter parameter) {
        return getListByParameter(null,null,parameter,FeedbackEntity.class);
    }

    @Override
    String getQuerySql() {
        return "select feedback_0.* from feedback as feedback_0";
    }

}
