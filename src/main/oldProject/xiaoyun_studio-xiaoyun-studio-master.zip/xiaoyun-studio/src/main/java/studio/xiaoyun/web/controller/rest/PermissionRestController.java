package studio.xiaoyun.web.controller.rest;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import studio.xiaoyun.core.constant.Permission;
import studio.xiaoyun.core.dao.IPermissionDao;
import studio.xiaoyun.core.entity.PermissionEntity;
import studio.xiaoyun.core.parameter.PermissionParameter;
import studio.xiaoyun.security.annotation.RequirePermission;
import studio.xiaoyun.web.ParameterUtil;
import studio.xiaoyun.web.ResourceUtil;
import studio.xiaoyun.web.RestResult;
import studio.xiaoyun.web.resource.PermissionResource;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/v1/permission")
public class PermissionRestController {
    @Resource
    private IPermissionDao permissionDao;
    @Resource
    private ResourceUtil resourceUtil;

    /**
     * 搜索权限
     * @param request http请求
     * @return 权限列表
     */
    @RequirePermission(Permission.PERMISSION_GET_ALL)
    @RequestMapping(value = "",method = RequestMethod.GET)
    public RestResult getPermissionByParameter(HttpServletRequest request){
        PermissionParameter param = ParameterUtil.getParameter(request, PermissionParameter.class);
        long count = permissionDao.getPermissionCountByParameter(param);
        List<PermissionEntity> list = permissionDao.getPermissionsByParameter(param);
        List<PermissionResource> resources = resourceUtil.toResource(list,param,PermissionResource.class);
        return new RestResult(count,resources);
    }

}
