package studio.xiaoyun.common.exception;

/**
 * 方法未实现时抛出该异常
 */
public class NotImplementedException extends XysException {
	private static final long serialVersionUID = -6384191391592436024L;
	private String message;

    public NotImplementedException() {
        super(ErrorCode.INTERNAL_SERVER_ERROR,"方法未实现");
        StackTraceElement[] stackTraces = Thread.currentThread().getStackTrace();
        message = "方法未实现:"+stackTraces[2].getClassName()+"#"+stackTraces[2].getMethodName();
    }

    @Override
    public String getMessage(){
        return message;
    }

    @Override
    public String toString(){
        return message;
    }

}
