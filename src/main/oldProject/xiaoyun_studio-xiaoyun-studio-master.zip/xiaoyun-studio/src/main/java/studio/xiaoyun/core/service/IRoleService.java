package studio.xiaoyun.core.service;

import java.util.Set;

/**
 * 角色相关
 */
public interface IRoleService {
    /**
     * 设置角色拥有的权限
     * @param roleId 角色id
     * @param permissionIds 权限id
     */
    void setRolePermission(String roleId,Set<String> permissionIds);
}
