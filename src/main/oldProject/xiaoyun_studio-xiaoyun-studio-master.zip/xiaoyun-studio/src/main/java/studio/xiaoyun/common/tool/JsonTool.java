package studio.xiaoyun.common.tool;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import studio.xiaoyun.common.exception.InvalidParameterException;
import studio.xiaoyun.common.exception.XysException;

import java.io.IOException;
import java.util.*;

/**
 * json相关的辅助类
 */
public class JsonTool {
    private static Logger logger = LoggerFactory.getLogger(JsonTool.class);
    private JsonTool(){}

    /**
     * 将json字符串转换为set。
     * <p>如果参数为null或者空，将返回空的集合</p>
     * @param json json格式的字符串
     * @return Set格式数据
     * @throws InvalidParameterException 如果参数格式错误，则抛出异常
     */
    public static Set stringToSet(String json) throws InvalidParameterException{
        if(StringUtils.isBlank(json)) return Collections.emptySet();
        try {
            return new ObjectMapper().readValue(json,Set.class);
        } catch (IOException e) {
            logger.debug("json转Set出错",e);
            throw new InvalidParameterException("参数不是一个Set:"+json);
        }
    }

    /**
     * 将json字符串转换为list。
     * <p>如果参数为null或者空，将返回空的集合</p>
     * @param json json格式的字符串
     * @return List格式数据
     * @throws InvalidParameterException 如果参数格式错误，则抛出异常
     */
    public static List stringToList(String json) throws InvalidParameterException{
        if(StringUtils.isBlank(json)) return Collections.emptyList();
        try {
            return new ObjectMapper().readValue(json,List.class);
        } catch (IOException e) {
            logger.debug("json转List出错",e);
            throw new InvalidParameterException("参数不是一个List:"+json);
        }
    }

    /**
     * 将json字符串转换为Map。
     * <p>如果参数为null或者空，将返回空的集合</p>
     * @param json json格式的字符串
     * @return Map格式数据
     * @throws InvalidParameterException 如果参数格式错误，则抛出异常
     */
    public static Map stringToMap(String json) throws InvalidParameterException{
        if(StringUtils.isBlank(json)) return Collections.emptyMap();
        try {
            return new ObjectMapper().readValue(json,Map.class);
        } catch (IOException e) {
            logger.debug("json转Map出错",e);
            throw new InvalidParameterException("参数不是一个Map:"+json);
        }
    }

    /**
     * 将对象转换为json字符串。
     * <p>对象中为null的值不会包含在json中，如果对象中包含日期类型的属性，将转换为yyyy-MM-dd HH:mm:ss格式</p>
     * @param obj 对象
     * @return json字符串
     */
    public static String objectToString(Object obj) {
        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        SimpleModule module = new SimpleModule();
        module.addSerializer(Date.class, new JsonSerializer<Date>(){
            @Override
            public void serialize(Date date, JsonGenerator generator, SerializerProvider provider) throws IOException {
                generator.writeString(DateFormatUtils.format(date,"yyyy-MM-dd HH:mm:ss"));
            }
        });
        mapper.registerModule(module);
        try {
            return mapper.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            logger.error("对象转json出错",e);
            throw new XysException("对象转json出错");
        }
    }

}
