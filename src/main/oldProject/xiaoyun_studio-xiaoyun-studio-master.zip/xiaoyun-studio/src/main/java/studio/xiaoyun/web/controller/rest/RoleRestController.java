package studio.xiaoyun.web.controller.rest;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import studio.xiaoyun.common.tool.JsonTool;
import studio.xiaoyun.core.constant.Permission;
import studio.xiaoyun.core.dao.IPermissionDao;
import studio.xiaoyun.core.dao.IRoleDao;
import studio.xiaoyun.core.entity.PermissionEntity;
import studio.xiaoyun.core.entity.RoleEntity;
import studio.xiaoyun.core.parameter.PermissionParameter;
import studio.xiaoyun.core.parameter.RoleParameter;
import studio.xiaoyun.core.service.IRoleService;
import studio.xiaoyun.security.annotation.RequirePermission;
import studio.xiaoyun.web.ParameterUtil;
import studio.xiaoyun.web.ResourceUtil;
import studio.xiaoyun.web.RestResult;
import studio.xiaoyun.web.resource.PermissionResource;
import studio.xiaoyun.web.resource.RoleResource;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Set;

/**
 * 角色相关
 */
@RestController
@RequestMapping("/v1/role")
public class RoleRestController {
    @Resource
    private IRoleDao roleDao;
    @Resource
    private ResourceUtil resourceUtil;
    @Resource
    private IPermissionDao permissionDao;
    @Resource
    private IRoleService roleService;

    /**
     * 获得所有角色
     * @param request http请求
     * @return 角色信息
     */
    @RequirePermission(Permission.ROLE_GET_ALL)
    @RequestMapping(value = "", method = RequestMethod.GET)
    public RestResult getRoleByParameter(HttpServletRequest request) {
        RoleParameter param = ParameterUtil.getParameter(request, RoleParameter.class);
        long count = roleDao.getRoleCountByParameter(param);
        List<RoleEntity> list = roleDao.getRolesByParameter(param);
        List<RoleResource> resources = resourceUtil.toResource(list, param, RoleResource.class);
        return new RestResult(count, resources);
    }

    /**
     * 获得角色拥有的权限
     * @param request http请求
     * @return 权限列表
     */
    @RequirePermission(Permission.PERMISSION_GET_BY_ROLEID)
    @RequestMapping(value = "/{id:\\S{32}}/permission", method = RequestMethod.GET)
    public RestResult getPermissionByRoleId(HttpServletRequest request, @PathVariable("id") String roleId) {
        PermissionParameter param = ParameterUtil.getParameter(request, PermissionParameter.class);
        long count = permissionDao.getPermissionCountByRoleId(roleId, param);
        List<PermissionEntity> list = permissionDao.getPermissionsByRoleId(roleId, param);
        List<PermissionResource> resources = resourceUtil.toResource(list, param, PermissionResource.class);
        return new RestResult(count, resources);
    }

    /**
     * 设置角色拥有的权限
     * @param request http请求
     * @param permissionId 权限id，json格式的Set集合
     */
    @RequirePermission(Permission.ROLE_UPDATE_PERMISSION)
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @RequestMapping(value = "/{id:\\S{32}}/permission", method = RequestMethod.POST)
    public void setRolePermission(HttpServletRequest request, @PathVariable("id") String roleId, String permissionId) {
        Set permissionSet = JsonTool.stringToSet(permissionId);
        roleService.setRolePermission(roleId,permissionSet);
    }
}
