package studio.xiaoyun.web.controller.rest;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.xpath;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import javax.annotation.Resource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.ContextHierarchy;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.JsonPath;

import studio.xiaoyun.common.exception.InvalidParameterException;
import studio.xiaoyun.core.dao.IFeedbackDao;
import studio.xiaoyun.core.dao.impl.TestUtil;
import studio.xiaoyun.core.entity.FeedbackEntity;
import studio.xiaoyun.web.HttpStatus;
import studio.xiaoyun.web.PublicParameter; 

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextHierarchy({  
    @ContextConfiguration(name = "parent", locations = "classpath:config/spring-context-test.xml"),  
    @ContextConfiguration(name = "child", locations = "classpath:config/spring-mvc-test.xml")  
}) 
public class FeedbackRestControllerClientTest {
	@Resource
	private WebApplicationContext wac;
	private MockMvc mockMvc;
	@Resource
	private IFeedbackDao feedbackDao;
	@Resource
	private TestUtil testUtil;

	@Before
	public void setup() throws Exception {
		testUtil.loginForAdmin();
	    this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
	}
	
	@Test
	public void testCreateFeedback() throws Exception {
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.put("/v1/feedback");
		request.param("title", "aaa");
		request.param("text", "bbb");
		request.param(PublicParameter.FORMAT.value(), "json");
		ResultActions action = mockMvc.perform(request);
		action.andExpect(status().is2xxSuccessful());
		String content = action.andReturn().getResponse().getContentAsString();
		String ID = JsonPath.read(content,"$.rows[0].feedbackId");
		String text = JsonPath.read(content, "$.rows[0].text");
		String title = JsonPath.read(content, "$.rows[0].title");
		FeedbackEntity feedback = feedbackDao.getById(ID);
		assertEquals("aaa",title);
		assertEquals("bbb",text);
		assertEquals("aaa",feedback.getTitle());
		assertEquals("bbb",feedback.getText());
	}

	@Test
	public void testGetFeedbackByID() throws Exception {
		FeedbackEntity feedback = new FeedbackEntity();
		feedback.setText("a");
		feedback.setTitle("b");
		String ID = feedbackDao.save(feedback);
		ResultActions action = mockMvc.perform(MockMvcRequestBuilders.get("/v1/feedback/"+ID+".json"));
		action.andExpect(status().isOk());
		String content = action.andReturn().getResponse().getContentAsString();
		int total = JsonPath.read(content, "$.total");
		String text = JsonPath.read(content, "$.rows[0].text");
		String title = JsonPath.read(content, "$.rows[0].title");
		assertEquals(1,total);
		assertEquals("a",text);
		assertEquals("b",title);
	}
	
	@Test
	public void testGetFeedbackByID2() throws Exception {
		ResultActions action = mockMvc.perform(MockMvcRequestBuilders.get("/v1/feedback/499fec455d554a288ef9114308a0f791.json"));
		action.andExpect(status().is4xxClientError());
	}
	
	@Test
	public void testGetFeedbackByID3() throws Exception {
		FeedbackEntity feedback = new FeedbackEntity();
		feedback.setText("a");
		feedback.setTitle("b");
		String ID = feedbackDao.save(feedback);
		ResultActions action = mockMvc.perform(MockMvcRequestBuilders.get("/v1/feedback/"+ID+".xml"));
		action.andExpect(status().isOk());
		action.andExpect(xpath("/response/total").number(1D));
		action.andExpect(xpath("/response/rows/array/text").string("a"));
		action.andExpect(xpath("/response/rows/array/title").string("b"));
	}

	@Test(expected = InvalidParameterException.class)
	public void testDeleteFeedbackByID() throws Exception {
		FeedbackEntity feedback = new FeedbackEntity();
		feedback.setText("a");
		feedback.setTitle("b");
		String ID = feedbackDao.save(feedback);
		ResultActions action = mockMvc.perform(MockMvcRequestBuilders.delete("/v1/feedback/"+ID+".json"));
		action.andExpect(status().is(HttpStatus.NO_CONTENT.value()));
		feedbackDao.getById(ID);
	}

	@Test
	public void testGetFeedbackByParameter() throws Exception {
		FeedbackEntity feedback = new FeedbackEntity();
		feedback.setText("a");
		feedback.setTitle("b");
		String ID = feedbackDao.save(feedback);
		Map<String,Object> map = new HashMap<>();
	    map.put("text", "a");
	    map.put("feedbackId",ID);
	    ObjectMapper mapper = new ObjectMapper();
	    String param = mapper.writeValueAsString(map);
	    MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get("/v1/feedback");
	    request.param(PublicParameter.FORMAT.value(), "json");
	    request.param(PublicParameter.QUERY.value(), param);
		ResultActions action = mockMvc.perform(request);
		action.andExpect(status().isOk());
		action.andExpect(jsonPath("$.total").value(1));
		action.andExpect(jsonPath("$.rows[0].feedbackId").value(ID));
		action.andExpect(jsonPath("$.rows[0].text").value("a"));
	}

}
