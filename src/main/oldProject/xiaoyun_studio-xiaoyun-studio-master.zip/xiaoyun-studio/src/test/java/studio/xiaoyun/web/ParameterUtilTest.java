package studio.xiaoyun.web;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import studio.xiaoyun.common.exception.XysException;
import studio.xiaoyun.core.parameter.TestParameter;

import java.text.SimpleDateFormat;
import java.util.*;

import static org.junit.Assert.*;

public class ParameterUtilTest {
	@Test
	public void getBoolean() throws Exception {
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter("a", "true");
		Boolean a = ParameterUtil.getBoolean(request,"a",null);
		assertTrue(a);
	}

	@Test
	public void getBoolean1() throws Exception {
		MockHttpServletRequest request = new MockHttpServletRequest();
		Boolean a = ParameterUtil.getBoolean(request,"a",null);
		assertNull(a);
	}

	@Test
	public void getBoolean2() throws Exception {
		MockHttpServletRequest request = new MockHttpServletRequest();
		Boolean a = ParameterUtil.getBoolean(request,"a",true);
		assertTrue(a);
	}

	@Test
	public void getBoolean3() throws Exception {
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter("a", "aaa");
		Boolean a = ParameterUtil.getBoolean(request,"a",null);
		assertFalse(a);
	}

	@Test
	public void testGetIntHttpServletRequestString() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter("a", "1");
		int i = ParameterUtil.getInt(request, "a",null);
		assertEquals(1,i);
	}
	
	@Test
	public void testGetIntHttpServletRequestString2() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		Integer i = ParameterUtil.getInt(request, "a",null);
		assertNull(i);
	}
	
	@Test(expected=XysException.class)
	public void testGetIntHttpServletRequestString3() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter("a", "a");
		ParameterUtil.getInt(request, "a",null);
	}

	@Test
	public void testGetIntHttpServletRequestStringInteger() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter("a", "1");
		int i = ParameterUtil.getInt(request, "a",0);
		assertEquals(1,i);
	}
	
	@Test
	public void testGetIntHttpServletRequestStringInteger2() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		int i = ParameterUtil.getInt(request, "a",0);
		assertEquals(0,i);
	}

	@Test
	public void testGetLongHttpServletRequestString() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter("a", "1");
		long i = ParameterUtil.getLong(request, "a",null);
		assertEquals(1L,i);
	}
	
	@Test
	public void testGetLongHttpServletRequestString2() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		Long i = ParameterUtil.getLong(request, "a",null);
		assertNull(i);
	}

	@Test(expected=XysException.class)
	public void testGetLongHttpServletRequestString3() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter("a", "1a");
		ParameterUtil.getLong(request, "a",null);
	}
	
	@Test
	public void testGetLongHttpServletRequestStringLong() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		long i = ParameterUtil.getLong(request, "a",1L);
		assertEquals(1L,i);
	}

	@Test
	public void testGetDoubleHttpServletRequestString() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter("a", "1");
		Double i = ParameterUtil.getDouble(request, "a",null);
		assertEquals(new Double(1),i);
	}
	
	@Test(expected=XysException.class)
	public void testGetDoubleHttpServletRequestString2() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter("a", "1a");
		ParameterUtil.getDouble(request, "a",null);
	}
	
	@Test
	public void testGetDoubleHttpServletRequestString3() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		Double i = ParameterUtil.getDouble(request, "a",null);
		assertNull(i);
	}

	@Test
	public void testGetDoubleHttpServletRequestStringDouble() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		Double i = ParameterUtil.getDouble(request, "a",1D);
		assertEquals(new Double(1),i);
	}

	@Test
	public void testGetString() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter("a", "你好");
		String s = ParameterUtil.getString(request, "a","s");
		assertEquals("你好",s);
	}
	
	@Test
	public void testGetString2() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		String s = ParameterUtil.getString(request, "a","s");
		assertEquals("s",s);
	}

	@Test
	public void testGetDateHttpServletRequestString() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter("a", "2010-01-01");
		Date d = ParameterUtil.getDate(request, "a");
		assertEquals("2010-01-01",new SimpleDateFormat("yyyy-MM-dd").format(d));
	}
	
	@Test
	public void testGetDateHttpServletRequestString2() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		Date d = ParameterUtil.getDate(request, "a");
		assertNull(d);
	}
	
	@Test(expected=XysException.class)
	public void testGetDateHttpServletRequestString3() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter("a", "2010-0sssss1-01");
		ParameterUtil.getDate(request, "a");
	}

	@Test
	public void testGetDateHttpServletRequestStringString() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter("a", "2010/01/01");
		Date d = ParameterUtil.getDate(request, "a","yyyy/MM/dd");
		assertEquals("2010-01-01",new SimpleDateFormat("yyyy-MM-dd").format(d));
	}

	@Test
	public void testGetParameterIn() throws Exception{
		Map<String,Object> map = new HashMap<String,Object>();
		Map<String,Object> map2 = new HashMap<String,Object>();
		map2.put("name", Arrays.asList("a","b"));
		map.put("_in", map2);
		ObjectMapper mapper = new ObjectMapper();
		String value = mapper.writeValueAsString(map);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter(PublicParameter.QUERY.value(), value);
		TestParameter param = ParameterUtil.getParameter(request, TestParameter.class);
		String query = param.getQuery();
		assertEquals("name in (?,?)",query);
	}
	
	@Test
	public void testGetParameterIn2() throws Exception{
		Map<String,Object> map = new HashMap<String,Object>();
		Map<String,Object> map2 = new HashMap<String,Object>();
		map2.put("ID1", Arrays.asList(new Integer(1),new Integer(2)));
		map.put("_in", map2);
		ObjectMapper mapper = new ObjectMapper();
		String value = mapper.writeValueAsString(map);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter(PublicParameter.QUERY.value(), value);
		TestParameter param = ParameterUtil.getParameter(request, TestParameter.class);
		String query = param.getQuery();
		assertEquals("ID1 in (?,?)",query);
	}
	
	@Test
	public void testGetParameterGt() throws Exception{
		Map<String,Object> map = new HashMap<>();
		Map<String,Object> map2 = new HashMap<>();
		map2.put("ID1", 1);
		map.put("_gt", map2);
		ObjectMapper mapper = new ObjectMapper();
		String value = mapper.writeValueAsString(map);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter(PublicParameter.QUERY.value(), value);
		TestParameter param = ParameterUtil.getParameter(request, TestParameter.class);
		String query = param.getQuery();
		assertEquals("ID1 > ?",query);
	}
	
	@Test
	public void testGetParameterGe() throws Exception{
		Map<String,Object> map = new HashMap<String,Object>();
		Map<String,Object> map2 = new HashMap<String,Object>();
		map2.put("ID1", 1);
		map.put("_ge", map2);
		ObjectMapper mapper = new ObjectMapper();
		String value = mapper.writeValueAsString(map);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter(PublicParameter.QUERY.value(), value);
		TestParameter param = ParameterUtil.getParameter(request, TestParameter.class);
		String query = param.getQuery();
		assertEquals("ID1 >= ?",query);
	}
	
	@Test
	public void testGetParameterLe() throws Exception{
		Map<String,Object> map = new HashMap<String,Object>();
		Map<String,Object> map2 = new HashMap<String,Object>();
		map2.put("ID1", 1);
		map.put("_le", map2);
		ObjectMapper mapper = new ObjectMapper();
		String value = mapper.writeValueAsString(map);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter(PublicParameter.QUERY.value(), value);
		TestParameter param = ParameterUtil.getParameter(request, TestParameter.class);
		String query = param.getQuery();
		assertEquals("ID1 <= ?",query);
	}

	@Test
	public void testGetParameterLt() throws Exception{
		Map<String,Object> map = new HashMap<String,Object>();
		Map<String,Object> map2 = new HashMap<String,Object>();
		map2.put("ID1", 1);
		map.put("_lt", map2);
		ObjectMapper mapper = new ObjectMapper();
		String value = mapper.writeValueAsString(map);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter(PublicParameter.QUERY.value(), value);
		TestParameter param = ParameterUtil.getParameter(request, TestParameter.class);
		String query = param.getQuery();
		assertEquals("ID1 < ?",query);
	}
	
	@Test
	public void testGetParameterEq() throws Exception{
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("name", "a");
		ObjectMapper mapper = new ObjectMapper();
		String value = mapper.writeValueAsString(map);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter(PublicParameter.QUERY.value(), value);
		TestParameter param = ParameterUtil.getParameter(request, TestParameter.class);
		String query = param.getQuery();
		assertEquals("name = ?",query);
	}
	
	@Test
	public void testGetParameterLike() throws Exception{
		Map<String,Object> map2 = new HashMap<>();
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("name", "%a");
		map2.put("_like", map);
		ObjectMapper mapper = new ObjectMapper();
		String value = mapper.writeValueAsString(map2);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter(PublicParameter.QUERY.value(), value);
		TestParameter param = ParameterUtil.getParameter(request, TestParameter.class);
		String query = param.getQuery();
		assertEquals("name like ?",query);
	}
	
	@Test
	public void testGetParameterAnd() throws Exception{
		Map<String,Object> map = new HashMap<>();
		Map<String,Object> map2 = new HashMap<>();
		map2.put("name", "%a");
		map.put("_like", map2);
		ObjectMapper mapper = new ObjectMapper();
		String value = mapper.writeValueAsString(map);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter(PublicParameter.QUERY.value(), value);
		TestParameter param = ParameterUtil.getParameter(request, TestParameter.class);
		String query = param.getQuery();
		assertEquals("name like ?",query);
	}
	
	@Test
	public void testGetParameterOr() throws Exception{
		Map<String,Object> map = new HashMap<>();
		Map<String,Object> map2 = new HashMap<>();
		Map<String,Object> map3 = new HashMap<>();
		List<Map<String,Object>> list = new ArrayList<>();
		map2.put("name", "a");
		map3.put("ID1", 1);
		list.add(map2);
		list.add(map3);
		map.put("_or", list);
		ObjectMapper mapper = new ObjectMapper();
		String value = mapper.writeValueAsString(map);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter(PublicParameter.QUERY.value(), value);
		TestParameter param = ParameterUtil.getParameter(request, TestParameter.class);
		String query = param.getQuery();
		assertTrue(query.equals("name = ? or ID1 = ?") || query.equals("ID1 = ? or name = ?"));
	}
	
	@Test
	public void testGetParameterOrAnd() throws Exception{
		Map<String,Object> map = new HashMap<>();
		Map<String,Object> map2 = new HashMap<>();
		Map<String,Object> map3 = new HashMap<>();
		Map<String,Object> map4 = new HashMap<>();
		Map<String,Object> map5 = new HashMap<>();
		Map<String,Object> map6 = new HashMap<>();
		List<Map<String,Object>> list = new ArrayList<>();
		map2.put("name", "a");
		map3.put("ID1", 1);
		map4.put("_like",map2);
		map5.put("_like",map3);
		list.add(map4);
		list.add(map5);
		map.put("_or", list);
		ObjectMapper mapper = new ObjectMapper();
		String value = mapper.writeValueAsString(map);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter(PublicParameter.QUERY.value(), value);
		TestParameter param = ParameterUtil.getParameter(request, TestParameter.class);
		String query = param.getQuery();
		assertTrue(query.equals("name like ? or ID1 like ?") );
	}
	
	@Test
	public void testGetIncludeFields() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter(PublicParameter.FIELD.value(), "name,ID1");
		List<String> list = ParameterUtil.getIncludeFields(request);
		assertEquals(2,list.size());
		assertEquals("name",list.get(0));
		assertEquals("ID1",list.get(1));
	}

	@Test
	public void testGetSortFields() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter(PublicParameter.SORT.value(), "name asc,ID1 desc");
		List<Object[]> list = ParameterUtil.getSortFields(request);
		assertEquals(2,list.size());
		assertEquals("name",list.get(0)[0]);
		assertTrue((Boolean)list.get(0)[1]);
		assertEquals("ID1",list.get(1)[0]);
		assertFalse((Boolean)list.get(1)[1]);
	}

	@Test
	public void testGetStart() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter(PublicParameter.START.value(), "1");
		int start = ParameterUtil.getStart(request);
		assertEquals(1,start);
	}
	
	@Test
	public void testGetStart2() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter(PublicParameter.PAGE.value(), "2");
		request.addParameter(PublicParameter.ROWS.value(), "2");
		int start = ParameterUtil.getStart(request);
		assertEquals(2,start);
	}

	@Test
	public void testGetRows() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter(PublicParameter.ROWS.value(), "2");
		int rows = ParameterUtil.getRows(request);
		assertEquals(2,rows);
	}

}
