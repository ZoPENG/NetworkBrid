package studio.xiaoyun.common.convert;

import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Test;

import studio.xiaoyun.common.tool.POITool;

public class IHtmlConverterTest {

	@Test
	public void testIsSupportedExtensions() {
		IHtmlConverter converter = new POITool();
		converter.setSupportedExtensionsForHtmlConverter(Arrays.asList("doc","DOCX",""));
		assertTrue(converter.isSupportedExtensionsForHtmlConverter("doc"));
		assertTrue(converter.isSupportedExtensionsForHtmlConverter("docx"));
		assertTrue(converter.isSupportedExtensionsForHtmlConverter(""));
		assertFalse(converter.isSupportedExtensionsForHtmlConverter("d"));
	}

}
