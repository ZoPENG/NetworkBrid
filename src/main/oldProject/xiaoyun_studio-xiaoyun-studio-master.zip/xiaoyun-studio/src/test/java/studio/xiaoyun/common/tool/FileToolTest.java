package studio.xiaoyun.common.tool;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.nio.charset.Charset;
import java.util.Optional;

import org.junit.Test;

public class FileToolTest {

    @Test
    public void getFileExtension() throws Exception {
        String fileName = "test.doc";
        String extension = FileTool.getFileExtension(fileName);
        assertEquals("doc",extension);
    }

    @Test
    public void getFileExtension2() throws Exception {
        String fileName = "test";
        String extension = FileTool.getFileExtension(fileName);
        assertEquals("",extension);
    }

    @Test
    public void getFileExtension3() throws Exception {
        String fileName = "test.DOC";
        String extension = FileTool.getFileExtension(fileName);
        assertEquals("doc",extension);
    }
    
    @Test
    public void getCharset(){
    	String text = "122你好";
    	ByteArrayInputStream input = new ByteArrayInputStream(text.getBytes());
    	Optional<Charset> o = FileTool.getCharset(input, 100);
    	assertTrue(o.isPresent());
    	assertEquals(o.get().toString(),"UTF-8");
    }
    
    @Test
    public void writeFile(){
    	String fileName = System.getProperty("java.io.tmpdir")+File.separator+"test.txt";
    	String text = "aaa啊啊你你胡搜aa";
    	FileTool.writeFile(fileName, text, Charset.forName("UTF-8"));
    	File file = new File(fileName);
    	assertTrue(file.exists());
    	String text2 = FileTool.readTextFile(fileName);
    	file.delete();
    	assertEquals(text,text2);
    }
    
}