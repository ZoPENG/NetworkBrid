package studio.xiaoyun.common.tool;

import org.junit.Test;
import studio.xiaoyun.web.Resource.TestResource;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.Assert.*;

public class JsonToolTest {
    @Test
    public void stringToSet() throws Exception {
        Set set = JsonTool.stringToSet("[\"a\",\"b\"]");
        assertEquals(2,set.size());
        assertTrue(set.contains("a"));
        assertTrue(set.contains("b"));
    }

    @Test
    public void stringToList() throws Exception {
        List set = JsonTool.stringToList("[\"a\",\"b\"]");
        assertEquals(2,set.size());
        assertTrue(set.contains("a"));
        assertTrue(set.contains("b"));
    }

    @Test
    public void stringToMap() throws Exception {
        Map map = JsonTool.stringToMap("{\"a\":1}");
        assertEquals(1,map.size());
        assertEquals("1",map.get("a").toString());
    }

    @Test
    public void objectToString() throws Exception {
        TestResource test = new TestResource();
        test.setName("a");
        String str = JsonTool.objectToString(test);
        assertEquals("{\"name\":\"a\"}",str);
    }

    @Test
    public void dateToString() throws Exception {
        TestResource test = new TestResource();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        test.setDate(format.parse("2001-01-01 10:10:10"));
        String str = JsonTool.objectToString(test);
        assertEquals("{\"date\":\"2001-01-01 10:10:10\"}",str);
    }

}