package studio.xiaoyun.core.parameter;

import studio.xiaoyun.core.parameter.criterion.Criterion;
import studio.xiaoyun.core.parameter.criterion.Query;

import java.util.List;

public class TestParameter2 extends Parameter {
    private String name;
    private Integer userId;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    List<Criterion> getDefaultValue() {
        List<Criterion> list = super.getDefaultValue();
        list.add(Query.equals("name","a"));
        return list;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }
}
