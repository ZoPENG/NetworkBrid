package studio.xiaoyun.core.dao.impl;

import org.hibernate.SQLQuery;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import studio.xiaoyun.common.exception.InvalidParameterException;
import studio.xiaoyun.core.entity.RoleEntity;
import studio.xiaoyun.core.entity.UserEntity;
import studio.xiaoyun.core.parameter.RoleParameter;
import studio.xiaoyun.core.parameter.criterion.Query;

import javax.annotation.Resource;
import java.util.*;

import static org.junit.Assert.*;

@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:config/spring-context-test.xml")
public class RoleDaoTest {
    @Resource
    private TestUtil testUtil;
    @Resource
    private RoleDao dao;
    @Resource
    private UserDao userDao;

    @Test
    public void getById() throws Exception {
        RoleEntity role = testUtil.createRole();
        RoleEntity role2 = dao.getById(role.getRoleId());
        assertEquals("查询出的结果不一样",role.getName(),role2.getName());
    }

    @Test(expected = InvalidParameterException.class)
    public void getById2() throws Exception {
        dao.getById("99999999999999999");
    }

    @Test(expected = Exception.class)
    public void loadById2() throws Exception {
        RoleEntity role = dao.loadById("9999999999999999");
        System.out.println(role.getRoleId());
    }

    @Test
    public void getRoleCountByParameter() throws Exception {
        RoleEntity role = testUtil.createRole();
        RoleParameter param = new RoleParameter();
        param.setRoleId(role.getRoleId());
        long count = dao.getRoleCountByParameter(param);
        assertEquals("根据id查询角色数量时有问题",1,count);
    }

    @Test
    public void getRoleCountByParameter2() throws Exception {
        RoleEntity role = testUtil.createRole();
        RoleParameter param = new RoleParameter();
        param.addQuery(Query.equals("name",role.getName()));
        long count = dao.getRoleCountByParameter(param);
        assertEquals("根据名称查询角色数量时有问题",1,count);
    }

    @Test
    public void getRoleCountByParameter3() throws Exception {
        String sql = "select count(*) from role";
        long count1 = dao.getCountBySQL(sql);
        long count2 = dao.getRoleCountByParameter(null);
        assertEquals("获得角色总数时有问题",count1,count2);
    }

    @Test
    public void getRolesByParameter() throws Exception {
        RoleEntity role = testUtil.createRole();
        RoleParameter param = new RoleParameter();
        param.setRoleId(role.getRoleId());
        List<RoleEntity> list = dao.getRolesByParameter(param);
        assertEquals(1,list.size());
        assertEquals("根据角色id查询出的结果不一样",role.getRoleId(),list.get(0).getRoleId());
    }

    @Test
    public void getRolesByParameter2() throws Exception {
        RoleEntity role = testUtil.createRole();
        RoleParameter param = new RoleParameter();
        param.addQuery(Query.equals("name",role.getName()));
        List<RoleEntity> list = dao.getRolesByParameter(param);
        assertEquals(1,list.size());
        assertEquals("根据角色名称查询出的结果不一样",role.getRoleId(),list.get(0).getRoleId());
    }

    @Test
    public void getRolesByParameter3() throws Exception {
        //制造测试数据
        RoleEntity role1 = testUtil.createRole();
        RoleEntity role2 = testUtil.createRole();
        //调用测试方法
        RoleParameter param = new RoleParameter();
        List<String> roleId = Arrays.asList(role1.getRoleId(), role2.getRoleId());
        param.addQuery(Query.in("roleId", roleId));
        param.addSort("name", false);
        List<RoleEntity> list = dao.getRolesByParameter(param);
        assertEquals(2, list.size());

        String sql = "SELECT role_0.* FROM role AS role_0 WHERE roleId IN (:roleId) ORDER BY name DESC";
        SQLQuery query = dao.getSession().createSQLQuery(sql);
        query.setParameterList("roleId", roleId);
        query.addEntity("role_0", RoleEntity.class);
        List<RoleEntity> list2 = query.list();
        assertEquals(2, list2.size());
        //判断结果和预期是否相同
        assertEquals("根据角色名称排序查询的结果不一样", list.get(0).getRoleId(), list2.get(0).getRoleId());
        assertEquals("根据角色名称排序查询的结果不一样", list.get(1).getRoleId(), list2.get(1).getRoleId());
    }

    @Test
    public void getRoleCountByUserId() throws Exception {
        RoleEntity role = testUtil.createRole();
        Set<RoleEntity> set = new HashSet<>();
        set.add(role);
        UserEntity user = testUtil.createUser();
        user.setRoles(set);
        userDao.update(user);
        dao.getSession().flush();

        long count = dao.getRoleCountByUserId(user.getUserId(),null);
        assertEquals(1,count);
    }

    @Test
    public void getRolesByUserId() throws Exception {
        RoleEntity role = testUtil.createRole();
        Set<RoleEntity> set = new HashSet<>();
        set.add(role);
        UserEntity user = testUtil.createUser();
        user.setRoles(set);
        userDao.update(user);
        dao.getSession().flush();

        List<RoleEntity> list = dao.getRolesByUserId(user.getUserId(),null);
        assertEquals(1,list.size());
        assertEquals(role.getRoleId(),list.get(0).getRoleId());
    }

}