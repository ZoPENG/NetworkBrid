package studio.xiaoyun.core.parameter.criterion;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Test;
import studio.xiaoyun.common.exception.XysException;
import studio.xiaoyun.core.parameter.TestParameter;

import java.util.Date;

import static org.junit.Assert.*;

public class CriterionTest {
    @Test
    public void getPropertyValue() throws Exception {
        Criterion c = Query.equals("name","aa");
        Object v = c.getPropertyValue(TestParameter.class,"name","aa");
        assertEquals(String.class,v.getClass());
    }

    @Test(expected = XysException.class)
    public void getPropertyValue2() throws Exception {
        Criterion c = Query.equals("name","aa");
        c.getPropertyValue(TestParameter.class,"name1","aa");
    }

    @Test
    public void getPropertyValue3() throws Exception {
        Criterion c = Query.equals("name", "aa");
        Object v = c.getPropertyValue(TestParameter.class, "ID1", 1);
        assertEquals("1", v.toString());
    }

    @Test
    public void getPropertyValue4() throws Exception {
        Criterion c = Query.equals("name", "aa");
        Object v = c.getPropertyValue(TestParameter.class, "enum1", TestEnum1.A);
        assertEquals(String.class, v.getClass());
        assertEquals("A", v.toString());
    }

    @Test
    public void getPropertyValue5() throws Exception {
        Criterion c = Query.equals("name","aa");
        Object v = c.getPropertyValue(TestParameter.class,"date",new Date());
        assertEquals(Date.class,v.getClass());
    }

    @Test
    public void getPropertyValue6() throws Exception {
        String dateStr = "2010-02-02";
        Criterion c = Query.equals("name","aa");
        Object v = c.getPropertyValue(TestParameter.class,"date",dateStr);
        assertEquals(Date.class,v.getClass());
        assertEquals(dateStr, DateFormatUtils.format((Date)v,"yyyy-MM-dd"));
    }

    @Test
    public void getPropertyValue7() throws Exception {
        String dateStr = "2010-02-02 20:02:30";
        Criterion c = Query.equals("name","aa");
        Object v = c.getPropertyValue(TestParameter.class,"date",dateStr);
        assertEquals(Date.class,v.getClass());
        assertEquals(dateStr, DateFormatUtils.format((Date)v,"yyyy-MM-dd HH:mm:ss"));
    }

}