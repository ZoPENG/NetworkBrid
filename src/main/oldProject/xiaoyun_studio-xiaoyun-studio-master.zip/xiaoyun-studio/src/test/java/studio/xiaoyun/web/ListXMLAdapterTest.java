package studio.xiaoyun.web;

import static org.junit.Assert.assertEquals;

import java.io.StringReader;
import java.io.StringWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.junit.Test;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import studio.xiaoyun.web.resource.Resource;

public class ListXMLAdapterTest {
	private XPath xpath = XPathFactory.newInstance().newXPath();
	private SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	//测试解析total
	@Test
	public void test1() throws Exception {
		Document doc = getDocument(11,null); 
		String total = (String)xpath.evaluate("/response/total", doc, XPathConstants.STRING);
		assertEquals("11",total);
	}
	
	//测试解析Map
	@Test
	public void test2()throws Exception{
		List<Map<String,Object>> list = new LinkedList<Map<String,Object>>();
		Map<String,Object> map= new HashMap<String,Object>();
		map.put("a", 1);
		map.put("b", "str");
		map.put("c", format.parse("2015-01-01 10:10:10"));
		map.put("d", new String[]{"a","b"});
		list.add(map);
		Document doc = getDocument(list); 
		String a = (String)xpath.evaluate("/response/rows/array/a", doc, XPathConstants.STRING);
		String b = (String)xpath.evaluate("/response/rows/array/b", doc, XPathConstants.STRING);
		String c = (String)xpath.evaluate("/response/rows/array/c", doc, XPathConstants.STRING);
		String d1 = (String)xpath.evaluate("/response/rows/array/d/array[1]", doc, XPathConstants.STRING);
		String d2 = (String)xpath.evaluate("/response/rows/array/d/array[2]", doc, XPathConstants.STRING);
		assertEquals("1",a);
		assertEquals("str",b);
		assertEquals("2015-01-01 10:10:10",c);
		assertEquals("a",d1);
		assertEquals("b",d2);
	}
	
	//测试解析Resource
	@Test
	public void test3()throws Exception{
		List<Resource> list = new LinkedList<>();
		TestResource2 resource2 = new TestResource2();
		list.add(resource2);
		Document doc = getDocument(list); 
		String aa = (String)xpath.evaluate("/response/rows/array/aa", doc, XPathConstants.STRING);
		String bb = (String)xpath.evaluate("/response/rows/array/bb", doc, XPathConstants.STRING);
		String cc = (String)xpath.evaluate("/response/rows/array/cc", doc, XPathConstants.STRING);
		String name = (String)xpath.evaluate("/response/rows/array/name", doc, XPathConstants.STRING);
		String dd1 = (String)xpath.evaluate("/response/rows/array/dd/aa", doc, XPathConstants.STRING);
		String dd2 = (String)xpath.evaluate("/response/rows/array/dd/bb", doc, XPathConstants.STRING);
		String dd3 = (String)xpath.evaluate("/response/rows/array/dd/cc", doc, XPathConstants.STRING);
		String ee1 = (String)xpath.evaluate("/response/rows/array/ee/array[1]", doc, XPathConstants.STRING);
		String ee2 = (String)xpath.evaluate("/response/rows/array/ee/array[2]", doc, XPathConstants.STRING);
		assertEquals("aa",aa);
		assertEquals("1",bb);
		assertEquals("2015-01-01 10:10:10",cc);
		assertEquals("name",name);
		assertEquals("aa",dd1);
		assertEquals("1",dd2);
		assertEquals("2015-01-01 10:10:10",dd3);
		assertEquals("a",ee1);
		assertEquals("b",ee2);
	}
	
	@SuppressWarnings("rawtypes")
	private Document getDocument(List rows)throws Exception{
		return getDocument(0,rows);
	}
	
	@SuppressWarnings("rawtypes")
	private Document getDocument(long total,List rows)throws Exception{
		HttpResponse response = new HttpResponse();
		response.setTotal(total);
		response.setRows(rows);
		JAXBContext context = JAXBContext.newInstance(HttpResponse.class);
		Marshaller marshaller = context.createMarshaller();
		StringWriter writer  = new StringWriter();
		marshaller.marshal(response, writer);
		String xml = writer.toString();
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setValidating(false);
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document doc = builder.parse(new InputSource(new StringReader(xml)));
		return  doc;
	}
	
	class TestResource1 implements Resource{
		private static final long serialVersionUID = 1L;
		 String aa  = null;
		 Integer bb;
		 Date cc;
		public String getAa() {
			return "aa";
		}
		public Integer getBb() {
			return 1;
		}
		public Date getCc() {
			Date date = null;
			try {
				date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse("2015-01-01 10:10:10");
			} catch (ParseException e) {
				e.printStackTrace();
			}
			return date;
		}
		
	}
	
	class TestResource2 extends TestResource1{
		private static final long serialVersionUID = 1L;
		 TestResource1 dd;
		 String[] ee;
		public TestResource1 getDd(){
			TestResource1 t = new TestResource1();
			return t;
		}
		public String[] getEe(){
			return new String[]{"a","b"};
		}
		public String getName(){
			return "name";
		}
		
	}

}
