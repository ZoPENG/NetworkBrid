package studio.xiaoyun.core.dao.impl;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.annotation.Repeat;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import studio.xiaoyun.core.entity.FeedbackEntity;
import studio.xiaoyun.core.parameter.FeedbackParameter;
import studio.xiaoyun.core.parameter.criterion.Query;

import javax.annotation.Resource;

import java.util.List;

import static org.junit.Assert.*;

@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:config/spring-context-test.xml")
public class FeedbackDaoTest {
    @Resource
    private FeedbackDao dao;
    @Resource
    private TestUtil testUtil;

    @Test
    public void getFeedbackCountByParameter() throws Exception {
        FeedbackEntity feedback = testUtil.createFeedback();
        FeedbackParameter param = new FeedbackParameter();
        param.setFeedbackId(feedback.getFeedbackId());
        long count = dao.getFeedbackCountByParameter(param);
        assertEquals(1,count);

    }

    @Test
    public void getFeedbacksByParameter() throws Exception {
        FeedbackEntity feedback = testUtil.createFeedback();
        FeedbackParameter param = new FeedbackParameter();
        param.setFeedbackId(feedback.getFeedbackId());
        List<FeedbackEntity> list = dao.getFeedbacksByParameter(param);
        assertEquals(1,list.size());
        assertEquals(feedback.getFeedbackId(),list.get(0).getFeedbackId());
    }

}