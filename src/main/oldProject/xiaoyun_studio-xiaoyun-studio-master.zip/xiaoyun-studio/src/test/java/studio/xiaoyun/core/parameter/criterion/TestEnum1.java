package studio.xiaoyun.core.parameter.criterion;

public enum TestEnum1 {
	A,B,C,D

}
