package studio.xiaoyun.core.dao.impl;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import studio.xiaoyun.core.constant.Permission;
import studio.xiaoyun.core.entity.PermissionEntity;
import studio.xiaoyun.core.entity.RoleEntity;
import studio.xiaoyun.core.entity.UserEntity;
import studio.xiaoyun.core.parameter.PermissionParameter;

import javax.annotation.Resource;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.Assert.*;

@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:config/spring-context-test.xml")
public class PermissionDaoTest {
    @Resource
    private PermissionDao dao;
    @Resource
    private TestUtil testUtil;
    @Resource
    private UserDao userDao;
    @Resource
    private RoleDao roleDao;

    @Test
    public void getPermissionsByParameter() throws Exception {
        PermissionParameter param = new PermissionParameter();
        param.setName(Permission.FEEDBACK_DELETE_BY_ID);
        List<PermissionEntity> list = dao.getPermissionsByParameter(param);
        assertEquals(1,list.size());
        assertEquals("查询出的结果和预期不同",Permission.FEEDBACK_DELETE_BY_ID,list.get(0).getName());
    }

    @Test
    public void getPermissionCountByParameter() throws Exception {
        PermissionParameter param = new PermissionParameter();
        param.setName(Permission.FEEDBACK_DELETE_BY_ID);
        long count = dao.getPermissionCountByParameter(param);
        assertEquals(1,count);
    }

    @Test
    public void getPermissionsByUserId() throws Exception {
        PermissionEntity permission = testUtil.getPermission();
        Set<PermissionEntity> set = new HashSet<>();
        set.add(permission);
        UserEntity user = testUtil.createUser();
        user.setPermissions(set);
        userDao.update(user);
        dao.getSession().flush();  //将修改提交到数据库

        List<PermissionEntity> list = dao.getPermissionsByUserId(user.getUserId(),null);
        assertEquals(1,list.size());
        assertEquals(permission.getName(),list.get(0).getName());
    }

    @Test
    public void getPermissionCountByUserId() throws Exception {
        PermissionEntity permission = testUtil.getPermission();
        Set<PermissionEntity> set = new HashSet<>();
        set.add(permission);
        UserEntity user = testUtil.createUser();
        user.setPermissions(set);
        userDao.update(user);
        dao.getSession().flush();  //将修改提交到数据库

        long count = dao.getPermissionCountByUserId(user.getUserId(),null);
        assertEquals(1,count);
    }

    @Test
    public void getPermissionsByRoleId() throws Exception {
        PermissionEntity permission = testUtil.getPermission();
        Set<PermissionEntity> set = new HashSet<>();
        set.add(permission);
        RoleEntity role = testUtil.createRole();
        role.setPermissions(set);
        roleDao.update(role);
        dao.getSession().flush();  //将修改提交到数据库

        List<PermissionEntity> list = dao.getPermissionsByRoleId(role.getRoleId(),null);
        assertEquals(1,list.size());
        assertEquals(permission.getPermissionId(),list.get(0).getPermissionId());
    }

    @Test
    public void getPermissionCountByRoleId() throws Exception {
        PermissionEntity permission = testUtil.getPermission();
        Set<PermissionEntity> set = new HashSet<>();
        set.add(permission);
        RoleEntity role = testUtil.createRole();
        role.setPermissions(set);
        roleDao.update(role);
        dao.getSession().flush();  //将修改提交到数据库

        long count = dao.getPermissionCountByRoleId(role.getRoleId(),null);
        assertEquals(1,count);
    }

}