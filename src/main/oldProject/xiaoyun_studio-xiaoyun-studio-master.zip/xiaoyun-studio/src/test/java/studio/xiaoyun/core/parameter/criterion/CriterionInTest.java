package studio.xiaoyun.core.parameter.criterion;

import org.junit.Test;
import studio.xiaoyun.core.parameter.TestParameter;

import java.util.Arrays;

import static org.junit.Assert.*;

public class CriterionInTest {
    @Test
    public void getQuery() throws Exception {
        Criterion c = Query.in("name", Arrays.asList("a","b","c"));
        String str = c.getQuery();
        assertEquals("%s in (?,?,?)",str);
    }

    @Test
    public void getQuery2() throws Exception {
        Criterion c = Query.in("name", Arrays.asList("a"));
        String str = c.getQuery();
        assertEquals("%s in (?)",str);
    }

}