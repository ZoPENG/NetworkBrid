package studio.xiaoyun.core.dao.impl;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.mgt.SecurityManager;
import org.hibernate.SQLQuery;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;
import studio.xiaoyun.core.constant.SystemUser;
import studio.xiaoyun.security.auth.CredentialsMatcher;
import studio.xiaoyun.common.exception.XysException;
import studio.xiaoyun.core.constant.UserStatus;
import studio.xiaoyun.core.constant.UserType;
import studio.xiaoyun.core.entity.FeedbackEntity;
import studio.xiaoyun.core.entity.PermissionEntity;
import studio.xiaoyun.core.entity.RoleEntity;
import studio.xiaoyun.core.entity.UserEntity;
import studio.xiaoyun.security.auth.UsernamePasswordToken;
import studio.xiaoyun.security.crypto.CipherService;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Repository
public class TestUtil {
    @Resource
    private SessionFactory sessionFactory;
    @Resource
    private CipherService cipherService;
    @Resource
    private SecurityManager securityManager;

    /**
     * 初始化shiro的安全管理器。
     * <p>如果测试时用到了shiro，需要调用该方法进行初始化</p>
     */
    public void initSecurityManager(){
        SecurityUtils.setSecurityManager(securityManager);
    }

    /**
     * 以管理员身份登陆
     */
    public void loginForAdmin(){
        initSecurityManager();
        if(!SecurityUtils.getSubject().isAuthenticated()){
            UsernamePasswordToken token = new UsernamePasswordToken(SystemUser.ADMIN.getName(), "1");
            token.setHost("127.0.0.1");
            token.setType(UserType.SYSTEM);
            SecurityUtils.getSubject().login(token);
        }
    }

    /**
     * 创建一个角色，每次创建的角色的名称和描述都不一样
     * @return 角色
     */
    public RoleEntity createRole(){
        String uuid = UUID.randomUUID().toString().replaceAll("-","");
        RoleEntity role = new RoleEntity();
        role.setName(uuid);
        role.setDescription(uuid);
        sessionFactory.getCurrentSession().save(role);
        sessionFactory.getCurrentSession().flush();
        return role;
    }

    /**
     * 创建一个用户，每次创建的用户的名称都不一样
     * @return 用户
     */
    public UserEntity createUser(){
        String uuid = UUID.randomUUID().toString().replaceAll("-","");
        UserEntity user = new UserEntity();
        user.setCreateDate(new Date());
        user.setName(uuid);
        user.setPassword(cipherService.encrypt("1"));
        user.setStatus(UserStatus.NORMAL);
        user.setType(UserType.USER);
        user.setEmail(uuid+"@xx.com");
        sessionFactory.getCurrentSession().save(user);
        sessionFactory.getCurrentSession().flush();
        return user;
    }

    /**
     * 从数据库中随机获得一条权限信息
     * @return 权限
     */
    public PermissionEntity getPermission(){
        String sql = "select a.* from permission as a order by rand()";
        SQLQuery query = sessionFactory.getCurrentSession().createSQLQuery(sql);
        query.setFirstResult(0);
        query.setMaxResults(1);
        query.addEntity("a",PermissionEntity.class);
        List<PermissionEntity> list = query.list();
        if(list.size()==0){
            throw new XysException("数据库中没有权限信息");
        }else{
            return list.get(0);
        }
    }

    /**
     * 创建一个反馈，每次创建的反馈的名称和内容都不一样
     * @return 反馈
     */
    public FeedbackEntity createFeedback(){
        String uuid = UUID.randomUUID().toString().replaceAll("-","");
        FeedbackEntity feedback = new FeedbackEntity();
        feedback.setCreateDate(new Date());
        feedback.setText(uuid);
        feedback.setTitle(uuid);
        sessionFactory.getCurrentSession().save(feedback);
        sessionFactory.getCurrentSession().flush();
        return feedback;
    }

}
