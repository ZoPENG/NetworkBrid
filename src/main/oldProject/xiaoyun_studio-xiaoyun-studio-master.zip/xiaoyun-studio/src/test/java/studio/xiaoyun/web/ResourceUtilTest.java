package studio.xiaoyun.web;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import studio.xiaoyun.core.dao.IFeedbackDao;
import studio.xiaoyun.core.entity.FeedbackEntity;
import studio.xiaoyun.core.parameter.FeedbackParameter;
import studio.xiaoyun.core.parameter.Parameter;
import studio.xiaoyun.core.parameter.TestParameter;
import studio.xiaoyun.web.Resource.TestResource;
import studio.xiaoyun.web.resource.FeedbackResource;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;

@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:config/spring-context-test.xml")
public class ResourceUtilTest {
	@Resource
	private ResourceUtil util;
	@Resource
	private IFeedbackDao dao;

	@Test
	public void toResource() {
		FeedbackEntity feedback = new FeedbackEntity();
		feedback.setText("aa");
		feedback.setTitle("bb");
		dao.save(feedback);
		List<FeedbackEntity> list = Collections.singletonList(feedback);
		List<FeedbackResource> resources = util.toResource(list,null,FeedbackResource.class);
		FeedbackResource resource = resources.get(0);
		assertEquals("aa",resource.getText());
		assertEquals("bb",resource.getTitle());
		assertEquals(feedback.getFeedbackId(),resource.getFeedbackId());
	}

	@Test
	public void testSetNull() {
		FeedbackEntity feedback = new FeedbackEntity();
		feedback.setText("aa");
		feedback.setTitle("bb");
		dao.save(feedback);
		List<FeedbackEntity> list = Collections.singletonList(feedback);
		FeedbackParameter param = new FeedbackParameter();
		param.addIncludeField("text","createDate");
		List<FeedbackResource> resources = util.toResource(list,param,FeedbackResource.class);
		FeedbackResource resource = resources.get(0);
		assertEquals("aa",resource.getText());
		assertNull(resource.getTitle());
		assertNotNull(resource.getCreateDate());
	}

	@Test
	public void testSetNull2() {
		TestResource test = new TestResource();
		test.setDate(new Date());
		test.setName("aa");
		test.setID1(1);
		Parameter param = new TestParameter();
		param.addIncludeField("date","name");
		ResourceUtil util = new ResourceUtil();
		util.setNull(Collections.singletonList(test), param);
		assertNotNull(test.getDate());
		assertNull(test.getID1());
		assertEquals("aa",test.getName());
	}
}
