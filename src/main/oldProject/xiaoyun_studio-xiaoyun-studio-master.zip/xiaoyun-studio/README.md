# 小云工作室
主页兼项目演示效果：[www.xiaoyun.studio](https://www.xiaoyun.studio)

*现在项目处于快速开发阶段，功能、架构等还没有确定*

### 特点
 * 恰当的注释、短少的类、见名知义的命名、优雅的异常处理和漂亮的代码风格一起构成整洁的代码
 * 除了类似于get/set这类简单的方法外，都有单元测试，保证代码质量
 * api采用restful风格，提供完善的文档，详细说明每个api的url、参数、返回值、异常码、状态码、权限
 * 前端使用bootstrap，使网页可以自适应用户的设备
 * 项目已经上线运行，新功能可以很快得到展示，搜索引擎搜索“小云工作室”就可以找到主页
 * office转pdf(支持wsoffice,wps,openoffice)，[office转html](https://www.xiaoyun.studio/app/preview.html)(支持wsoffice,wps,openoffice,poi)，检测文件编码

### 部署
检出源码后只需要maven自动下载好jar，就可以启动项目，所有配置都提供了默认值。数据库默认使用h2，系统启动时会自动创建表，自动导入用户、权限等初始数据。

部分jar在maven中央仓库中没有，需要手动从doc目录复制到本地仓库中

这里有一篇使用eclipse导入源码的教程：[点我点我～](https://www.xiaoyun.studio/article/sourceTutorial.html)
 
### 技术框架
 * 核心框架：spring 4
 * MVC框架：spring mvc 4
 * 持久层：hibernate 5
 * 安全框架：shiro
 * 日志管理：logback
 * 数据库：h2、mysql
 * js框架：jquery 3
 * css框架：bootstrap 3
 * 单元测试：junit 4
 
### 欢迎加入
 小云工作室期待您的加入！！！